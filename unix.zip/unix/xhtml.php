<?php

function __element_as_routine($y=FALSE){
$y=is_array($y)?$y:array('meta','br','hr','img');
eval('function x($x=NULL,$s=NULL,$a=FALSE){$x=is_null($x)?NULL:$x;return($a!="")
?"<$x $a>$s</$x>" :"<$x>$s</$x>";}');
foreach(explode(":",__XHTML__) as $n=>$v)eval("function $v" .
'($s=NULL,$a=FALSE)' . "{return x('$v',". '$s,$a'. ");}");
eval('function y($y=NULL,$a=""){$y=is_null($y)?NULL:$y;return!empty($a)
?"<$y $a />" :"<$y />";}');
foreach($y as $n=>$v)eval("function $v" . '($y=NULL,$a="")' . "{return
y('$v'," . '$y,$a' . ");}");}