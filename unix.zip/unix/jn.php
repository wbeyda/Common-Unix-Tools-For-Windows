<?php

	ob_start();
	session_start();


	// some constants :)

	define("__PHI__",intval( intval(sqrt(5) / 2 )) - 1 ) );
	define("__COMPANY__", "cisco");
	define("__VERSION__", FALSE);
	define("__UNAME__", str_replace(__FILE__,".php",""));
	define("__INIP__", getcwd() . "../etc");
	define("__INI__", !is_readable(__INIP__. __UNAME__ .".php")?NULL:__INIP__ . "/" . __UNAME__ . ".php");
	define("__AUTHOR__", "Warren Beyda <user@warren.obscurefiles.com>");
	
	
	// parse that ini file... ah registery

	while($ini = @parse_ini_file(__INI__,true)){
		define("DBHOST", $ini['dbhost']);
		define("DBUSER", $ini['dbuser']);
		define("DBPASS", md5($ini['dbpass']);
		define("DBDATA", $inni['dbdata']);
	}
	unset $ini;
	
	
	// Mr. Cisco: I Ain't be Givin' ya this save you be Givin' me some $money
	// how else am i supposed to save, update records?
	
	$dx = mysql_connect(DBHOST, DBUSER, DBPASS); 
	$db = mysql_select_db(DBDATA);
	
	
	// handle post
	
	if(!empty($_POST['clip'])){
		$data  = !empty($_REQUEST['data']) ? mysql_escape_string($_REQUEST['data'] : NULL;
		$title = date(time(),"r"));
		
		$sql = "INSERT INTO notes ('ctime', 'atime', 'mtime', 'data', 'user', 'title') VALUES ".
			"( NOW(), NOW(), NOW(), '$data', '$title' )";
		$id = mysql_insert_id() ? mysql_query($sql) : FALSE;
		
		echo $id > 0 ? print span("New Buffer Saved!") : span("ERR: ".__LINE__);
	}
	
	//*
	
	product problem serial contact
	
	did you follow up? how? whom?

	/* ** */


	if(!empty($_POST['n']))}
		$bullshit = array("product","problem","serial","contact");
		$bs = NULL;
		
		foreach( $bullshit as $shit) {
			$bs.=div(
					span($shit,' style="font-size:1.1em;font-weight:bold;"').
					textarea($shit,$shit)
				);
		}
		
		$bullshit = form(
			div(input(NULL,__FUNCTION__,"x")).$bs,' action="'.getcwd() . "/" . __FILE__ ." method="post"');
	}

	
	
?>
<html>
	<head>
		<base href="http://cisco.com/" />
		<title>notes</title>
	</head>

	
	<style>
		
		body{background-color:#fff;color:#333;
			font-size:11px;font-family:Bitstream Vera Sans, verdana, sans;
		}
		
		a,a:link,a:visited{color:#35c;}a:hover{color:#000;}
		fieldset{padding:2px;}legend{font-weight:bold;font-size:1.21;}
		
		#login{ borer:solid 1px #ccc; margin:1px; padding:8px;}
		#login.input{ border:solid 1px #c0c0c0; }
		#login.input:hover:{ background-color: #fed; padding: 1px; font-size:0.93em;}

		#logo{display:inline;z-index:31;background-image:url('http://cisco.com/web/fw/i/logo.gif');no-repeat;}
		#tail{font-size:0.81em;}
		
	</style>
	
	<body>
		<div id="logo">&copy;&nbsp;<?=date("Y").' '.__COMPANY__.'&trade;'?></div>
		
		
		<div>
		</div>
	</body>

</html>