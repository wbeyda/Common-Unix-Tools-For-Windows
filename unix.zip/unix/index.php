<?=eval('?'. '><' .'?');

 /*	for those it may help: routine for looping through an array of strings for
	*	internal evaluation as html element named functions
	* in other words, provides: html(), div(), form(input()) etc...
	* don't forget to DECLARE !DOCTYPE :)

	* author: <jrey at localhost> 127.0.0.1
	* perhaps there is another that could use this snippet, a few people
	* have requested it from me but here it is for the world
	************************************************************************************/

	ob_start(); //<= catch all stdio

	header("HTTP/1.1 200 Ok");//<= RFC2616
	header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
	header("Cache-Control: no-cache, must-revalidate");

	echo PHP_EOL, NULL;


	function __w3c_xhtml_strict($s='',$t='',$p=''){
		return
		xhtml(
			head(
				title( __FUNCTION__ ).
				meta( 'http-equiv="content-type" content="text/html;charset=UTF-8"' )
			).	"\n\n".
			body(
				div( empty($str)?(intval($_REQUEST['src'])>0?htmlentities(print_r(file($_SERVER['PHP_SELF']))):$str) : __FILE__ )
			)
		);
	}

	/*
	 * functions - I wrote these last summer as txt msgs to myself. Finally in the end
	 * learned to stream each 160 byte chunk as apendages to server side code.
	/**/


	function xhtml($d='strict',$s=''){
		// default strict : en for now
		$d=($d==='transistional')?$d:'strict';
		$e='xmlns="http://www.w3.org/1999/'.__FUNCTION__.'" xml:lang="en" lang="en"';
		// return to append
		$r=
			"\<\!DOCTYPE html PUBLIC -//W3C//DTD ".
			strtoupper(__FUNCTION__). ' 1.0 ' .ucfirst($d).
			'//EN\r\n"http://www.w3.org/TR/xhtml1/DTD/xhtml1-'.
			strtolower($d).".dtd\"\r\n";

		// default content
		$s=empty($s)
			?number_format(round(intval(filesize(__FILE__)/1024),2)).'kb'
			:($s==1?NULL:htmlentities($s));

// some day check for the constant __compile and compare against it
// get net access
		return $r . html("'{$s}'\r\n",$e);
	}

	function __compile($y=0){

		/*
		 * eval string for x() and y()
		 * loop through x() and y() for <element properties>string</element>
		 * and <element properties />
		 /* ** */

		$e=( // elements
			'body:button:code:div:dt:em:fieldset:form:h1:h2:h3:h4:h5:h6:head:html:iframe:legend:li:noframes:'.
			'noscript:object:ol:option:p:pre:select:script:span:strong:style:td:textarea:th:title:tr:tt:ul'
		);
		$y=!is_array($y)?array('meta','br','hr','img'):array($y);
		eval('
			function prop($str){return " style=\"$str\"";}
		');
		eval('
			function x($x=NULL,$s=NULL,$a=FALSE){$x=is_null($x) ? NULL : $x;
			return($a!="") ? "<$x $a>$s</$x>" : "<$x>$s</$x>";
		}');
		eval('
			function y($y=NULL,$a=""){
			$y=is_null($y) ? NULL : $y;return!empty($a) ? "<$y $a />" : "<$y />";
		}');
		foreach(explode(":",$e) as $n=>$v)eval("
			function $v" . '($s=NULL,$a=FALSE)' . "{return x('$v',". '$s,$a'. ");}");
		foreach($y as $n=>$v)eval("
			function $v" . '($y=NULL,$a="")' . "{return y('$v'," . '$y,$a' . ");}");

		// proprietory
		//eval("\?\>\<\?=eval(\"foreach(explode('exe:css:js',':')as $k=>$v){is_callable($v)?call_user_func($v):NULL


		// sanity check
		return (function_exists("p") && function_exists("br")) ? @xhtml() : FALSE;
	}
	/* ******************** ******************** */
//EOF