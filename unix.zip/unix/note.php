<?=eval('?'. '><' .'?');

	ob_start(); //<= catch all stdio
	session_start();

	header("HTTP/1.1 200 Ok");//<= RFC2616
	header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
	header("Cache-Control: no-cache, must-revalidate");

	echo PHP_EOL, (intval(init()>0)?notes();

	
	function init(){
		define("__UNAME__", "NotNotes");
		define("__VERSION__", "0.0.1");
		return true;
	}
	
	// No loose code below - only routine
	
	function query(){
		$q = parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH);

	}
	
	
	function notes(){
		$form = css_str(' name="general" action="{$_SERVER['PHP_SELF']}" method="post" onsubmit="betterMo();"');
		$table = table(
		);
		return
		h1(__UNAME__ . __VERSION__,css("style1")).
		div(
			fieldset(legend("Clipboard").
				form(
					div(input(NULL,__PIN__,"x"));
					div(textarea,$form)
			).
				form($table,$form)
			)
		);
	}
	

<h2 align="center" class="style1"> NotNotes 0.7 </h2>

<form  name="general" action="#" onsubmit="betterMo(); return false">
<table align="center" class="form">
<tr>
<td><textarea cols="50" rows="7" name="general2"></textarea></td>
</tr>
<tr>
<td><input type="reset" /></td>
</tr>
</table>

</form>



<form name="NotNote" action="#" onsubmit="checkit(); return false">
<table align="center" class="form">
<tr>
<td nowrap="nowrap">Product</td>
<td nowrap="nowrap"><input class="#box" name="Product" /></td>
</tr>

<tr>
<td nowrap="nowrap">Problem</td>
<td nowrap="nowrap"><input class="box" name="Problem" /></td>
</tr>

<tr>
<td nowrap="nowrap">Serial</td>
<td nowrap="nowrap"><input class="box" name="Serial" /></td>
</tr>

<tr>
<td nowrap="nowrap">Contract</td>
<td nowrap="nowrap"><input class="box" name="Contract" /></td>
</tr>

<tr>
<td nowrap="nowrap">When Creating this Service Request did you?</td>
<td nowrap="nowrap">

<input type="radio" name="Method" value="Bypass Entitlement" />Bypass Entitlement<br />
<input type="radio" name="Method" value="Checked the Contract Entitlement" />Checked the Contract Entitlement<br />
<input type="radio" name="Method" value="Added a contract to a profile " />Added a contract to a profile <br /></td></tr>

<tr>
<td nowrap="nowrap">Did you Auto-Route or Manually Route?
<td nowrap="nowrap"><select name="refer">
  <option value='' selected="selected">--- Select ---</option>
  <option value="Auto-Route">Auto-Route</option>
  <option value="Manually Route">Manually Route</option>

</select>

</tr>

<tr>
<td nowrap="nowrap">How did you contact the engineer?</td>
<td nowrap="nowrap">
<input type="checkbox" name="Voicemail " />Voicemail<br />
<input type="checkbox" name="WebEx " />WebEx<br />
<input type="checkbox" name="E-Page " />E-Page<br />
<input type="checkbox" name="Email " />Email<br /></td>
</tr>

<tr>
<td nowrap="nowrap">Did you contact another Group?
<td nowrap="nowrap"><select name="contact">
  <option value='' selected="selected">--- Select ---</option>
  <option value="Yes I contacted another Group">Yes</option>
  <option value="No I did not contact another Group">No</option>
</select>
</tr>

<tr>

<td nowrap="nowrap">How did you contact the Group?</td>
<td nowrap="nowrap">
<input type="checkbox" name="WebEx " />WebEx<br />
<input type="checkbox" name="Phone " />Phone<br /></td>
</tr>

<br />

<tr>
<td nowrap="nowrap">When did you make contact?</td>
<td nowrap="nowrap"><input class="box" name="When" /></td>
</tr>

<br />

<tr>
<td nowrap="nowrap">Who did you contact?</td>
<td nowrap="nowrap"><input class="box" name="Who" /></td>
</tr>


<tr>
<td nowrap="nowrap"><input type="submit" value="Submit form" />
  <input type="reset" /></td>
</tr><br />

<tr><td colspan="2" nowrap="nowrap"><textarea cols="70" rows="10" name="bigbox">NotNotes Rules!</textarea></td></tr>

</table>
</form>

<h2 align="center" class="style1">Example of Great Notes!</h2>

<tr>
  <td colspan="2"><div align="center">
    <textarea align="center" class="textarea2" name="GreatNotes">Customer calling to request that their SR be requeued due to not being able to  contact the current engineer assigned to the case. Attempted to contact the  engineer via WebEx  no response. Checked COT tool for 24x7 availablity. Attempted to contact engineer via E-Page  no response. Attempted to contact engineer via phone  Received engineers voicemail  left message. Explained to customer that if we requeue that it may take some time for the new engineer to get updated on the case and also that it may take up to an hour for the customer to receive a call back. Customer still requesting requeue. Requeueing to the same department due to the team being on shift.</textarea>
  </div></td>
</tr>
</table>

<h2 align="center" class="style1"> Weekend Instructions</h2>
 
<tr>
  <td colspan="2"><div align="center">
    <textarea align="center" class="textarea2" name="GreatNotes">Customer calling to request that their SR be requeued due to not being able to  contact the current engineer assigned to the case. Attempted to contact the  engineer via WebEx  no response. Checked COT tool for 24x7 availablity. Attempted to contact engineer via E-Page  no response. Attempted to contact engineer via phone  Received engineers voicemail  left message. Explained to customer that if we requeue that it may take some time for the new engineer to get updated on the case and also that it may take up to an hour for the customer to receive a call back. Customer still requesting requeue. Requeueing by auto route due to weekend instructions.</textarea>
  </div></td>
</tr>
</table>

<h2 align="center" class="style1"> Warm Transfer</h2>

 
<tr>
  <td colspan="2"><div align="center">
    <textarea align="center" class="textarea3" name="GreatNotes">Customer called in asking to check on the status of their Service Request. I messaged the engineer on webex and then warm transfered the customer.</textarea>
  </div></td>
</tr>
</table>


<h3 align="center" class="style1"> Usefull Phone Numbers</h3>

<p>
Cisco Contract Center<br>
1-800 556 1343 

</p>

<p>
 GSR<br>
 1-919-574-0028
</p>

<p>
Presales<br>

1-585-340-3495
</p>

<p>
Asset Recovery<br>
1-800-800-1180 ex 67284
</p>

<p>
Linksys<br>
1-800-326-7114
</p>

<p>
STAC<br>

1-866-940-4246
</p>

<p>
Logistics<br>
1-800 553 2447 Option 4 or 1 408 526 5744 
</p>

<p>
HTTS<br>
1-800-495-9121
</p>

<p>
Customer Service<br>

1-408-902-4180
</p>

<p>
PRT<br>
1-919-574-1162
</p>

<p>
Order Management<br>
1-800-553-6387 op 2: op 1 status op 2 expidit/change
</p>

<p>
Career Certifications<br>

18005536387 op 4 op 1
</p>

<p>
Pizza<br>
1-801-967-5700
</p>

<h3 align="center" class="style1"> Awesome Links!</h3>

<p>
<a href="http://wwwin.cisco.com/it/services/pu-support_numbers.shtml"> Support Contact Numbers</a><br>

</p>

<p>
<a href="http://www-tac.cisco.com/cgi-bin/schedule-parser.pl?">Schedule-parser</a> + Group = Engineers onshift<br>
example: http://www-tac.cisco.com/cgi-bin/schedule-parser.pl?WW-LICENSING
</p>

<p>
<center>
<font size="0.1">

Copyright (C) 2009, 2010 Warren Beyda. <br>
This program is free software licensed under the GNU General Public License
See <a href="http://www.gnu.org/licenses/">http://www.gnu.org/licenses/</a> for full license.


</font>
</center>
</p>
	
	
	
	
	}
	
	
	
	function __w3c_xhtml_strict($s='',$t='',$p=''){
		return
		xhtml(
			head(
				title( __FUNCTION__ ).
				meta( 'http-equiv="content-type" content="text/html;charset=UTF-8"' )
			).	"\n\n".
			body(
				div( empty($str)?(intval($_REQUEST['src'])>0?htmlentities(print_r(file($_SERVER['PHP_SELF']))):$str) : __FILE__ )
			)
		);
	}

	/*
	 * functions - I wrote these last summer as txt msgs to myself. Finally in the end
	 * learned to stream each 160 byte chunk as apendages to server side code.
	/**/


	function xhtml($d='strict',$s=''){
		// default strict : en for now
		$d=($d==='transistional')?$d:'strict';
		$e='xmlns="http://www.w3.org/1999/'.__FUNCTION__.'" xml:lang="en" lang="en"';
		// return to append
		$r=
			"\<\!DOCTYPE html PUBLIC -//W3C//DTD ".
			strtoupper(__FUNCTION__). ' 1.0 ' .ucfirst($d).
			'//EN\r\n"http://www.w3.org/TR/xhtml1/DTD/xhtml1-'.
			strtolower($d).".dtd\"\r\n";

		// default content
		$s=empty($s)
			?number_format(round(intval(filesize(__FILE__)/1024),2)).'kb'
			:($s==1?NULL:htmlentities($s));

// some day check for the constant __compile and compare against it
// get net access
		return $r . html("'{$s}'\r\n",$e);
	}

	function __compile($y=0){

		/*
		 * eval string for x() and y()
		 * loop through x() and y() for <element properties>string</element>
		 * and <element properties />
		 /* ** */

		$e=( // elements
			'body:button:code:div:dt:em:fieldset:form:h1:h2:h3:h4:h5:h6:head:html:iframe:legend:li:noframes:'.
			'noscript:object:ol:option:p:pre:select:script:span:strong:style:td:textarea:th:title:tr:tt:ul'
		);
		$y=!is_array($y)?array('meta','br','hr','img'):array($y);
		eval('
			function prop($str){return " style=\"$str\"";}
		');
		eval('
			function x($x=NULL,$s=NULL,$a=FALSE){$x=is_null($x) ? NULL : $x;
			return($a!="") ? "<$x $a>$s</$x>" : "<$x>$s</$x>";
		}');
		eval('
			function y($y=NULL,$a=""){
			$y=is_null($y) ? NULL : $y;return!empty($a) ? "<$y $a />" : "<$y />";
		}');
		foreach(explode(":",$e) as $n=>$v)eval("
			function $v" . '($s=NULL,$a=FALSE)' . "{return x('$v',". '$s,$a'. ");}");
		foreach($y as $n=>$v)eval("
			function $v" . '($y=NULL,$a="")' . "{return y('$v'," . '$y,$a' . ");}");

		// proprietory
		//eval("\?\>\<\?=eval(\"foreach(explode('exe:css:js',':')as $k=>$v){is_callable($v)?call_user_func($v):NULL


		// sanity check
		return (function_exists("p") && function_exists("br")) ? @xhtml() : FALSE;
	}
	/* ******************** ******************** */
//EOF


	function logout(){
		return stristr("logout",$_SERVER['REQUEST_URI']) ? eval('session_destroy();') : NULL;
	}