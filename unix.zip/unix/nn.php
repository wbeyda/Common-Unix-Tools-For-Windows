<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en">
<head>
<title>Not Notes</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script>
<!--

var caution = false

// name - name of the cookie
// value - value of the cookie
// [expires] - expiration date of the cookie (defaults to end of current session)
// [path] - path for which the cookie is valid (defaults to path of calling document)
// [domain] - domain for which the cookie is valid (defaults to domain of calling document)
// [secure] - Boolean value indicating if the cookie transmission requires a secure transmission
// * an argument defaults when it is assigned null as a placeholder
// * a null placeholder is not required for trailing omitted arguments

function setCookie(name, value, expires, path, domain, secure) {
var curCookie = name + "=" + escape(value) +
((expires) ? "; expires=" + expires.toGMTString() : "") +
((path) ? "; path=" + path : "") +
((domain) ? "; domain=" + domain : "") +
((secure) ? "; secure" : "")
if (!caution || (name + "=" + escape(value)).length <= 4000)
document.cookie = curCookie
else
if (confirm("Cookie exceeds 4KB and will be cut!"))
document.cookie = curCookie
}

// name - name of the desired cookie
// * return string containing value of specified cookie or null if cookie does not exist
function getCookie(name) {
var prefix = name + "="
var cookieStartIndex = document.cookie.indexOf(prefix)
if (cookieStartIndex == -1)
return null
var cookieEndIndex = document.cookie.indexOf(";", cookieStartIndex + prefix.length)
if (cookieEndIndex == -1)
cookieEndIndex = document.cookie.length
return unescape(document.cookie.substring(cookieStartIndex + prefix.length, cookieEndIndex))
}

// name - name of the cookie
// [path] - path of the cookie (must be same as path used to create cookie)
// [domain] - domain of the cookie (must be same as domain used to create cookie)
// * path and domain default if assigned null or omitted if no explicit argument proceeds
function deleteCookie(name, path, domain) {
if (getCookie(name)) {
document.cookie = name + "=" +
((path) ? "; path=" + path : "") +
((domain) ? "; domain=" + domain : "") +
"; expires=Thu, 01-Jan-70 00:00:01 GMT"
}
}

// date - any instance of the Date object
// * you should hand all instances of the Date object to this function for "repairs"
// * this function is taken from Chapter 14, "Time and Date in JavaScript", in "Learn Advanced JavaScript Programming"
function fixDate(date) {
var base = new Date(0)
var skew = base.getTime()
if (skew > 0)
date.setTime(date.getTime() - skew)
}

var now = new Date()
fixDate(now)
now.setTime(now.getTime() + 31 * 24 * 60 * 60 * 1000)
var name = getCookie("name")
if (!name)
name = prompt("Please enter your name:", "John Doe")
setCookie("name", name, now)
document.write("Hello " + name + "!")
//-->
</script>


<script type="text/javascript">
<!--

// This is a clear and mousetrap function

	function betterMo() {
		document.general.reset();
}



// This is the check script

function checkit()
{
	// In textstring I gather the data that are finally written to the textarea.

	var textstring = '';

	// First of all, have all the text boxes been filled in?
	// This part is treated in the normal page.
	// I put all boxes and their values in textstring

	for (i=0;i<4;i++) {
		var box = document.forms['NotNote'].elements[i];
		   if (!box.value) {
			alert('You haven\'t filled in ' + box.name + '!');
			box.focus()
			return; 
		}
		textstring += box.name + ': ' + box.value + '\n';
	}


	// Get value of the 'Method' radio buttons.

	user_input = '';
	for (i=0;i<document.forms['NotNote'].Method.length;i++) {
		if (document.forms['NotNote'].Method[i].checked) {
			user_input = document.forms['NotNote'].Method[i].value;
		}
	}
	textstring += 'Method: ' + user_input + '\n';

	// Get value of the 'Routing Method' select box.

	user_input = document.NotNote.refer.options[document.NotNote.refer.selectedIndex].value
	textstring += 'Routing Method: ' + user_input + '\n';

	// See what checkboxes are checked. They are elements 8-12

	textstring += 'Contact Method: ';
	for (i=8;i<12;i++) {
		if (document.NotNote.elements[i].checked) {
			textstring += document.NotNote.elements[i].name+'\n';
		}
	}

	// Get value of the 'contact' select box.

	user_input = document.NotNote.contact.options[document.NotNote.contact.selectedIndex].value
	textstring += 'Alternate Group Contacted: ' + user_input + '\n';

	// See what checkboxes are checked. They are elements 8-13

	textstring += 'Contact Method For Alternate Group: ';
	for (i=13;i<15;i++) {
		if (document.NotNote.elements[i].checked) {
			textstring += document.NotNote.elements[i].name+'\n';
		}
	}

	// Another loop to get the value of 'When' and 'Who' inputboxes 

	for (i=15;i<17;i++) {
		var box = document.forms['NotNote'].elements[i];
		if (!box.value) {
			alert('You haven\'t filled in ' + box.name + '!');
			box.focus()
			return; 
		}
		textstring += box.name + ': ' + box.value + '\n';
	}


// Write textstring to the textarea.

	document.forms['NotNote'].bigbox.value = textstring;
}
// -->
</script>
<style type="text/css">

body {
	font-size: 67.5%;
	font-family: Tahoma, sans-serif;
	background-color: #94AFDA;
}

p, li {
	font-size: 1.4em;
	text-align: center;
}

h2 {
	font-size: 2.1em;
}

h3 {
	font-size: 1.6em;
}

#page-wrap {
	margin: 20px auto;
	width: 750px;
}

textarea {
	width: 500px;
	height: 120px;
	border: 3px solid #cccccc;
	padding: 5px;
	font-family: Tahoma, sans-serif;
	background-image: none;
	background-position: right bottom;
	background-repeat: no-repeat;
}

textarea2 {
	width: 250px;
	height: 60px;
	border: 3px solid #cccccc;
	padding: 5px;
	font-family: Tahoma, sans-serif;
	background-image: none;
	background-position: right bottom;
	background-repeat: no-repeat;
}

textarea3 {
	width: 250px;
	height: 30px;
	border: 3px solid #cccccc;
	padding: 5px;
	font-family: Tahoma, sans-serif;
	background-image: none;
	background-position: right bottom;
	background-repeat: no-repeat;
}

#box {
	border: 3px solid #cccccc;
	padding: 5px;
}

.style1 {color: #cccccc}
</style>
</head>

<body>


<h2 align="center" class="style1"> NotNotes 0.7 </h2>

<form  name="general" action="#" onsubmit="betterMo(); return false">
<table align="center" class="form">
<tr>
<td><textarea cols="50" rows="7" name="general2"></textarea></td>
</tr>
<tr>
<td><input type="reset" /></td>
</tr>
</table>

</form>



<form name="NotNote" action="#" onsubmit="checkit(); return false">
<table align="center" class="form">
<tr>
<td nowrap="nowrap">Product</td>
<td nowrap="nowrap"><input class="#box" name="Product" /></td>
</tr>

<tr>
<td nowrap="nowrap">Problem</td>
<td nowrap="nowrap"><input class="box" name="Problem" /></td>
</tr>

<tr>
<td nowrap="nowrap">Serial</td>
<td nowrap="nowrap"><input class="box" name="Serial" /></td>
</tr>

<tr>
<td nowrap="nowrap">Contract</td>
<td nowrap="nowrap"><input class="box" name="Contract" /></td>
</tr>

<tr>
<td nowrap="nowrap">When Creating this Service Request did you?</td>
<td nowrap="nowrap">

<input type="radio" name="Method" value="Bypass Entitlement" />Bypass Entitlement<br />
<input type="radio" name="Method" value="Checked the Contract Entitlement" />Checked the Contract Entitlement<br />
<input type="radio" name="Method" value="Added a contract to a profile " />Added a contract to a profile <br /></td></tr>

<tr>
<td nowrap="nowrap">Did you Auto-Route or Manually Route?
<td nowrap="nowrap"><select name="refer">
  <option value='' selected="selected">--- Select ---</option>
  <option value="Auto-Route">Auto-Route</option>
  <option value="Manually Route">Manually Route</option>

</select>

</tr>

<tr>
<td nowrap="nowrap">How did you contact the engineer?</td>
<td nowrap="nowrap">
<input type="checkbox" name="Voicemail " />Voicemail<br />
<input type="checkbox" name="WebEx " />WebEx<br />
<input type="checkbox" name="E-Page " />E-Page<br />
<input type="checkbox" name="Email " />Email<br /></td>
</tr>

<tr>
<td nowrap="nowrap">Did you contact another Group?
<td nowrap="nowrap"><select name="contact">
  <option value='' selected="selected">--- Select ---</option>
  <option value="Yes I contacted another Group">Yes</option>
  <option value="No I did not contact another Group">No</option>
</select>
</tr>

<tr>

<td nowrap="nowrap">How did you contact the Group?</td>
<td nowrap="nowrap">
<input type="checkbox" name="WebEx " />WebEx<br />
<input type="checkbox" name="Phone " />Phone<br /></td>
</tr>

<br />

<tr>
<td nowrap="nowrap">When did you make contact?</td>
<td nowrap="nowrap"><input class="box" name="When" /></td>
</tr>

<br />

<tr>
<td nowrap="nowrap">Who did you contact?</td>
<td nowrap="nowrap"><input class="box" name="Who" /></td>
</tr>


<tr>
<td nowrap="nowrap"><input type="submit" value="Submit form" />
  <input type="reset" /></td>
</tr><br />

<tr><td colspan="2" nowrap="nowrap"><textarea cols="70" rows="10" name="bigbox">NotNotes Rules!</textarea></td></tr>

</table>
</form>

<h2 align="center" class="style1">Example of Great Notes!</h2>

<tr>
  <td colspan="2"><div align="center">
    <textarea align="center" class="textarea2" name="GreatNotes">Customer calling to request that their SR be requeued due to not being able to  contact the current engineer assigned to the case. Attempted to contact the  engineer via WebEx  no response. Checked COT tool for 24x7 availablity. Attempted to contact engineer via E-Page  no response. Attempted to contact engineer via phone  Received engineers voicemail  left message. Explained to customer that if we requeue that it may take some time for the new engineer to get updated on the case and also that it may take up to an hour for the customer to receive a call back. Customer still requesting requeue. Requeueing to the same department due to the team being on shift.</textarea>
  </div></td>
</tr>
</table>

<h2 align="center" class="style1"> Weekend Instructions</h2>
 
<tr>
  <td colspan="2"><div align="center">
    <textarea align="center" class="textarea2" name="GreatNotes">Customer calling to request that their SR be requeued due to not being able to  contact the current engineer assigned to the case. Attempted to contact the  engineer via WebEx  no response. Checked COT tool for 24x7 availablity. Attempted to contact engineer via E-Page  no response. Attempted to contact engineer via phone  Received engineers voicemail  left message. Explained to customer that if we requeue that it may take some time for the new engineer to get updated on the case and also that it may take up to an hour for the customer to receive a call back. Customer still requesting requeue. Requeueing by auto route due to weekend instructions.</textarea>
  </div></td>
</tr>
</table>

<h2 align="center" class="style1"> Warm Transfer</h2>

 
<tr>
  <td colspan="2"><div align="center">
    <textarea align="center" class="textarea3" name="GreatNotes">Customer called in asking to check on the status of their Service Request. I messaged the engineer on webex and then warm transfered the customer.</textarea>
  </div></td>
</tr>
</table>


<h3 align="center" class="style1"> Usefull Phone Numbers</h3>

<p>
Cisco Contract Center<br>
1-800 556 1343 

</p>

<p>
 GSR<br>
 1-919-574-0028
</p>

<p>
Presales<br>

1-585-340-3495
</p>

<p>
Asset Recovery<br>
1-800-800-1180 ex 67284
</p>

<p>
Linksys<br>
1-800-326-7114
</p>

<p>
STAC<br>

1-866-940-4246
</p>

<p>
Logistics<br>
1-800 553 2447 Option 4 or 1 408 526 5744 
</p>

<p>
HTTS<br>
1-800-495-9121
</p>

<p>
Customer Service<br>

1-408-902-4180
</p>

<p>
PRT<br>
1-919-574-1162
</p>

<p>
Order Management<br>
1-800-553-6387 op 2: op 1 status op 2 expidit/change
</p>

<p>
Career Certifications<br>

18005536387 op 4 op 1
</p>

<p>
Pizza<br>
1-801-967-5700
</p>

<h3 align="center" class="style1"> Awesome Links!</h3>

<p>
<a href="http://wwwin.cisco.com/it/services/pu-support_numbers.shtml"> Support Contact Numbers</a><br>

</p>

<p>
<a href="http://www-tac.cisco.com/cgi-bin/schedule-parser.pl?">Schedule-parser</a> + Group = Engineers onshift<br>
example: http://www-tac.cisco.com/cgi-bin/schedule-parser.pl?WW-LICENSING
</p>

<p>
<center>
<font size="0.1">

Copyright (C) 2009, 2010 Warren Beyda. <br>
This program is free software licensed under the GNU General Public License
See <a href="http://www.gnu.org/licenses/">http://www.gnu.org/licenses/</a> for full license.


</font>
</center>
</p>

</body>
</html>

